// ✅ src/pages/TaskDistributionRun.tsx
// ✅ كود كامل بدون أخطاء JSX/TS
// ✅ إصلاح خطأ: Duplicate function implementation ts(2393) (تم حذف الدالة المكررة)
// ✅ تعديل مهم حسب طلبك: الحد الأقصى للنصاب لكل معلم = (مراقبة + احتياط + مراجعة) فقط
//    ❌ التصحيح CORRECTION_FREE لا يدخل ضمن maxTasksPerTeacher ولا ضمن إجمالي النصاب
//
// ✅ تحديث أسماء المعلمين دائمًا من صفحة المعلمين (LocalStorage) عند كل تشغيل + عند فتح الصفحة
// ✅ حل مشكلة التوزيع = صفر بسبب عدم تطابق date/dateISO عبر تطبيع البيانات
// ✅ نقل أزرار (الجدول الشامل/طباعة PDF/حذف بيانات التوزيع) أعلى جدول العدالة
// ✅ زر حذف جميع بيانات التوزيع (يمسح العدالة + الجدول الشامل لأنه نفس run)
//
// ✅ منطق التوزيع:
// 1) maxTasksPerTeacher (Quota) = INVIGILATION + RESERVE + REVIEW_FREE فقط
// 2) Round-Robin للمهام غير المراقبة
// 3) المراقبة Min-Inv First لتحقيق مساواة قدر الإمكان
// 4) إسناد: مراقبة ثم احتياط ثم مراجعة
//
// ✅ شروط المراجعة/التصحيح كما هو (مع منع التداخل):
// - REVIEW_FREE (حسب subject1 فقط) يحجز اليوم كامل AM+PM ولا يسمح بغيره بهذا اليوم
// - CORRECTION_FREE: يحجز اليوم كامل AM+PM لمنع أي INV/RES بهذا اليوم
// - التصحيح يُحسب فقط “اليوم التالي” لامتحانات المواد الفعلية الموجودة في جدول الامتحانات
//
// ✅ الشروط السابقة (حسب طلبك):
// 1) الجمعة والسبت إجازة: لا يتم توزيع أي مهام عليهما، وكل المهام تُرحّل إلى يوم الأحد
// 2) شرط "بن" داخل نفس اللجنة (قاعة):
//    - إذا كان في اللجنة مراقب واحد: يجب أن يحتوي اسم المعلم على كلمة " بن "
//    - إذا كان عدد المراقبين 2:
//      - ممنوع (بدون "بن" + بدون "بن") في نفس القاعة
//      - مسموح (بن+بن) أو (بن+بدون بن)
//
// ✅ الشروط الجديدة (حسب طلبك):
// - المعلم الذي يحتوي اسمه على 12 يوزع أولاً عند توزيع امتحان مادة تحتوي على 12 (مثال "الرياضة المدرسية 12")
//   وإن لم يوجد اسم بهذه المواصفات يوزع على باقي المعلمين
// - المعلم الذي يحتوي اسمه على 13 لا يوزع في آخر يوم اختبار (مراقبة/احتياط)
// - المعلم الذي يحتوي اسمه على 14 لا يوزع في آخر يومين اختبار (مراقبة/احتياط)
// - المعلم الذي يتم توزيعه مراقبة ثلاث ساعات (180 دقيقة) لا يتم توزيعه مرة أخرى مراقبة ثلاث ساعات
//
// ✅ NEW (حسب طلبك النهائي):
// ✅ فاضي للتصحيح (CORRECTION_FREE) شرطه:
//   - اليوم التالي فقط (يوم واحد) = الأساسي
//   - للصفوف 1-4: المطابقة تكون نفس "اسم المادة" مع أي من subject1..subject4
//   - للصفوف 5-12: المطابقة تكون حسب مجموعات التصحيح المحددة
//   - لا يوجد أي ترحيل/shift لأيام أخرى للتصحيح

import React, { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../auth/AuthContext";
import { useAppData } from "../context/AppDataContext";
import { loadTenantArray, writeTenantAudit } from "../services/tenantData";

import type { DistributionDebug, UnfilledSlotDebug } from "../contracts/taskDistributionContract";
import { saveRun, loadRun, clearRun, RUN_UPDATED_EVENT } from "../utils/taskDistributionStorage";
import {
  buildUnavailabilityIndex,
  isTeacherUnavailable,
  loadUnavailability,
} from "../utils/taskDistributionUnavailability";

const CONSTRAINTS_KEY = "exam-manager:task-distribution:constraints:v2";
const AUTORUN_KEY = "exam-manager:task-distribution:autorun:v1";

// ✅ Settings page reads this (fallback) when run is missing
const MASTER_TABLE_KEY = "exam-manager:task-distribution:master-table:v1";
// ✅ (Optional) old keys that may exist in some builds
const RESULTS_TABLE_KEY = "exam-manager:task-distribution:results-table:v1";
const ALL_TABLE_KEY = "exam-manager:task-distribution:all-table:v1";

const TEACHERS_STORAGE_KEY = "exam-manager:teachers:v1";
const EXAMS_STORAGE_KEY = "exam-manager:exams:v1";

const LOGO_URL = "https://i.imgur.com/vdDhSMh.png";
const APP_NAME = "برنامج ادارة الامتحانات الذكي";

function num(v: string, fallback: number) {
  const x = Number(v);
  return Number.isFinite(x) ? x : fallback;
}

function loadSavedConstraints(): any | null {
  try {
    const raw = localStorage.getItem(CONSTRAINTS_KEY);
    if (!raw) return null;
    return JSON.parse(raw);
  } catch {
    return null;
  }
}
function saveConstraintsToLS(c: any) {
  try {
    localStorage.setItem(CONSTRAINTS_KEY, JSON.stringify(c));
  } catch {}
}
function clearConstraintsLS() {
  try {
    localStorage.removeItem(CONSTRAINTS_KEY);
  } catch {}
}

const DEFAULT_CONSTRAINTS: any = {
  maxTasksPerTeacher: 10, // ✅ نصاب (مراقبة+احتياط+مراجعة) فقط
  reservePerPeriod: 1,

  invigilators_5_10: 2,
  invigilators_11: 2,
  invigilators_12: 2,

  avoidBackToBack: true,
  smartBySpecialty: true,
  freeAllSubjectTeachersForCorrection: true,

  // ✅ تفريغ معلمي المادة للتصحيح
  // - ALL: كل أيام التصحيح (اليوم التالي لكل امتحان)
  // - DATES: أيام محددة فقط
  correctionFreeMode: "ALL",
  correctionFreeDatesISO: [] as string[],
  // (Deprecated) دعم قديم ليوم واحد
  correctionFreeDateISO: "",

  // ✅ السماح بفترتين
  allowTwoPeriodsSameDay: false,
  allowTwoPeriodsSameDayAllDates: true, // true = كل الأيام، false = تواريخ محددة
  allowTwoPeriodsSameDayDates: [] as string[], // قائمة YYYY-MM-DD

  // ✅ عدد محاولات التحسين لاختيار أقل عجز (كل تشغيل سيختلف عن السابق)
  optimizationAttempts: 5,

  correctionDays: 1,
};

type FairRow = {
  teacherId: string;
  teacherName: string;
  inv: number;
  res: number;
  rev: number;
  cor: number;
  total: number; // ✅ مجموع (inv+res+rev) فقط
};

// ✅ مهام تدخل في نصاب maxTasksPerTeacher
function isQuotaTaskType(t: any) {
  return t === "INVIGILATION" || t === "RESERVE" || t === "REVIEW_FREE";
}

function normalizeSearch(s: string) {
  return String(s || "")
    .trim()
    .toLowerCase()
    .replace(/\s+/g, " ");
}

function reasonLabel(code: string) {
  switch (code) {
    case "NO_TEACHERS":
      return "لا يوجد معلمين";
    case "MAX_TASKS_REACHED":
      return "وصل الحد الأقصى للنصاب";
    case "PERIOD_CONFLICT":
      return "تعارض في نفس الفترة";
    case "BACK_TO_BACK_BLOCK":
      return "منع حسب القيود";
    case "REVIEW_FREE_BLOCK":
      return "مفرّغ للمراجعة";
    case "CORRECTION_FREE_BLOCK":
      return "مفرّغ للتصحيح";
    case "SPECIALTY_BLOCK":
      return "ممنوع لمعلم المادة";
    case "ARABIC_ONCE":
      return "اللغة العربية (مرة واحدة)";
    case "THREE_HOURS_ALREADY":
      return "مراقبة 3 ساعات سبق تنفيذها";
    case "UNAVAILABLE":
      return "غير متاح (غياب/عدم توفر)";
    default:
      return "سبب غير معروف";
  }
}

// ✅ قراءة مباشرة من LocalStorage لضمان أحدث بيانات
function safeParseArray(raw: string | null): any[] {
  if (!raw) return [];
  try {
    const x = JSON.parse(raw);
    return Array.isArray(x) ? x : [];
  } catch {
    return [];
  }
}

function readTeachersFromLS(): any[] {
  const arr = safeParseArray(localStorage.getItem(TEACHERS_STORAGE_KEY));
  return arr
    .map((t) => ({
      id: String(t.id ?? "").trim(),
      employeeNo: String(t.employeeNo ?? "").trim(),
      fullName: String(t.fullName ?? "").trim(),
      name: String(t.name ?? "").trim(),
      subject1: String(t.subject1 ?? "").trim(),
      subject2: String(t.subject2 ?? "").trim(),
      subject3: String(t.subject3 ?? "").trim(),
      subject4: String(t.subject4 ?? "").trim(),
      grades: String(t.grades ?? "").trim(),
      phone: String(t.phone ?? "").trim(),
      notes: String(t.notes ?? "").trim(),
    }))
    .filter((t) => t.id && (t.fullName || t.name || t.employeeNo));
}

function readExamsFromLS(): any[] {
  const arr = safeParseArray(localStorage.getItem(EXAMS_STORAGE_KEY));
  return arr
    .map((e) => {
      const dateISO = String(e.dateISO ?? e.date ?? "").trim();
      return {
        id: String(e.id ?? "").trim(),
        subject: String(e.subject ?? "").trim(),
        dateISO,
        date: dateISO,
        dayLabel: String(e.dayLabel ?? "").trim(),
        time: String(e.time ?? "").trim(),
        durationMinutes: Number(e.durationMinutes ?? 0) || 0,
        period: String(e.period ?? "").trim(), // "الفترة الأولى/الثانية" أو "AM/PM"
        roomsCount: Number(e.roomsCount ?? 0) || 0,
      };
    })
    .filter((e) => e.id && e.subject && e.dateISO);
}

function getEffectiveTenantId(userTenantId: string | null | undefined) {
  return (userTenantId && String(userTenantId).trim()) || "default";
}

/* ============================================================
   ✅ تحديد نوع المهمة بوضوح
============================================================ */
const TASK_TYPE_LABEL_AR: Record<string, string> = {
  INVIGILATION: "مراقبة",
  RESERVE: "احتياط",
  REVIEW_FREE: "مراجعة",
  CORRECTION_FREE: "تصحيح",
};

function ensureExplicitTaskTypes(out: any) {
  const assigns: any[] = Array.isArray(out?.assignments) ? out.assignments : [];
  for (const a of assigns) {
    const t = String(a?.taskType || "").trim();
    const safeType = t || "RESERVE";
    a.taskType = safeType;
    a.taskTypeLabelAr = TASK_TYPE_LABEL_AR[safeType] || "غير محدد";
  }
  return out;
}

/* ============================================================
   ✅ Helpers: Subjects + Period normalize + Dates
============================================================ */
function buildTeacherSubjectsMapAll(teachers: any[]) {
  const map = new Map<string, Set<string>>();
  for (const t of teachers || []) {
    const id = String(t.id ?? "").trim();
    if (!id) continue;
    const subjects = new Set<string>();
    [t.subject1, t.subject2, t.subject3, t.subject4].forEach((s: any) => {
      const v = String(s ?? "").trim();
      if (v) subjects.add(v);
    });
    map.set(id, subjects);
  }
  return map;
}

// ✅ subject1 فقط (شرط التفريغ للمراجعة)
function buildTeacherSubject1Map(teachers: any[]) {
  const map = new Map<string, string>(); // teacherId -> subject1
  for (const t of teachers || []) {
    const id = String(t.id ?? "").trim();
    if (!id) continue;
    map.set(id, String(t.subject1 ?? "").trim());
  }
  return map;
}

function periodToAMPM(p: string): "AM" | "PM" {
  const x = String(p || "").trim();
  if (!x) return "AM";
  if (x === "AM" || x === "PM") return x;
  if (x.includes("الثانية")) return "PM";
  if (x.includes("الأولى")) return "AM";
  return "AM";
}

function guessInvigilatorsPerRoom(exam: any, constraints: any): number {
  const subj = String(exam?.subject || "");
  if (/\b11\b/.test(subj) || subj.includes("11")) return Number(constraints.invigilators_11 || 2) || 2;
  if (/\b10\b/.test(subj) || subj.includes("10")) return Number(constraints.invigilators_5_10 || 2) || 2;
  return Number(constraints.invigilators_12 || 2) || 2;
}

function slotKey(dateISO: string, period: "AM" | "PM") {
  return `${dateISO}__${period}`;
}

// ✅ إضافة يوم (YYYY-MM-DD) بشكل آمن (UTC)
function addDaysISO(dateISO: string, days: number) {
  const m = String(dateISO || "").trim().match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (!m) return dateISO;
  const y = Number(m[1]);
  const mo = Number(m[2]);
  const d = Number(m[3]);
  const dt = new Date(Date.UTC(y, mo - 1, d));
  dt.setUTCDate(dt.getUTCDate() + days);
  const yy = dt.getUTCFullYear();
  const mm = String(dt.getUTCMonth() + 1).padStart(2, "0");
  const dd = String(dt.getUTCDate()).padStart(2, "0");
  return `${yy}-${mm}-${dd}`;
}

/* ============================================================
   ✅ عطلة الجمعة/السبت -> ترحيل للأحد
============================================================ */
function isFriOrSat(dateISO: string) {
  const m = String(dateISO || "").trim().match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (!m) return false;
  const y = Number(m[1]);
  const mo = Number(m[2]);
  const d = Number(m[3]);
  const dt = new Date(Date.UTC(y, mo - 1, d));
  const day = dt.getUTCDay(); // 0=Sun, 5=Fri, 6=Sat
  return day === 5 || day === 6;
}

function shiftWeekendToSunday(dateISO: string) {
  const m = String(dateISO || "").trim().match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (!m) return dateISO;
  const y = Number(m[1]);
  const mo = Number(m[2]);
  const d = Number(m[3]);
  const dt = new Date(Date.UTC(y, mo - 1, d));
  const day = dt.getUTCDay(); // 0=Sun,5=Fri,6=Sat

  if (day === 5) dt.setUTCDate(dt.getUTCDate() + 2); // Fri -> Sun
  else if (day === 6) dt.setUTCDate(dt.getUTCDate() + 1); // Sat -> Sun

  const yy = dt.getUTCFullYear();
  const mm = String(dt.getUTCMonth() + 1).padStart(2, "0");
  const dd = String(dt.getUTCDate()).padStart(2, "0");
  return `${yy}-${mm}-${dd}`;
}

function workDateISO(dateISO: string) {
  const d = String(dateISO || "").trim();
  if (!d) return d;
  return isFriOrSat(d) ? shiftWeekendToSunday(d) : d;
}

/* ============================================================
   ✅ شرط "بن" في الاسم
============================================================ */
function normalizeArabicSpaces(s: string) {
  return String(s || "").replace(/\s+/g, " ").trim();
}
function hasBenInName(name: string) {
  const n = " " + normalizeArabicSpaces(name) + " ";
  return n.includes(" بن ");
}

/* ============================================================
   ✅ NEW: شروط 12 / 13 / 14 + 3 ساعات
============================================================ */
function hasNumInText(text: string, n: number) {
  const s = String(text || "");
  return s.includes(String(n));
}
function teacherHas12(name: string) {
  return hasNumInText(name, 12);
}
function teacherHas13(name: string) {
  return hasNumInText(name, 13);
}
function teacherHas14(name: string) {
  return hasNumInText(name, 14);
}
function subjectHas12(subject: string) {
  return hasNumInText(subject, 12);
}

/* ============================================================
   ✅ Randomization helpers (لجعل كل تشغيل مختلف مع أقل عجز)
============================================================ */
function mulberry32(seed: number) {
  let t = seed >>> 0;
  return function () {
    t += 0x6d2b79f5;
    let r = Math.imul(t ^ (t >>> 15), 1 | t);
    r ^= r + Math.imul(r ^ (r >>> 7), 61 | r);
    return ((r ^ (r >>> 14)) >>> 0) / 4294967296;
  };
}

function seededShuffle<T>(arr: T[], seed: number): T[] {
  const a = [...arr];
  const rnd = mulberry32(seed);
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(rnd() * (i + 1));
    const tmp = a[i];
    a[i] = a[j];
    a[j] = tmp;
  }
  return a;
}

/* ============================================================
   ✅ مجموعات التصحيح + NEW: تمييز الصف 1-4 عن 5-12
============================================================ */
function normSubj(s: string) {
  return String(s || "")
    .trim()
    .replace(/\s+/g, " ")
    .toLowerCase();
}

// ✅ استخراج رقم الصف من نص المادة (1..12) إن وجد
function extractGradeFromSubject(subject: string): number | null {
  const s = String(subject || "");
  // نلتقط 1-12 حتى لو حولها حروف/مسافات
  const m = s.match(/(^|[^\d])((1[0-2])|([1-9]))([^\d]|$)/);
  if (!m) return null;
  const n = Number(m[2]);
  if (!Number.isFinite(n)) return null;
  if (n >= 1 && n <= 12) return n;
  return null;
}

// ✅ مجموعة التصحيح للصفوف 5-12 فقط (حسب شروطك)
function getCorrectionGroupKey_5_12(subject: string) {
  const s = normSubj(subject);

  // (الرياضيات من 5 إلى 10 + الرياضيات الأساسية + الرياضيات المتقدمة 11 إلى 12) مجموعة واحدة
  if (s.includes("رياضيات") || s.includes("الرياضيات") || s.includes("الرياضيات الأساسية") || s.includes("الرياضيات المتقدمة"))
    return "G5_12_MATH";

  // (التربية الإسلامية من 5 إلى 12)
  if (s.includes("التربية الإسلامية") || s.includes("تربية إسلامية") || s.includes("اسلامية") || s.includes("إسلامية"))
    return "G5_12_ISLAMIC";

  // (اللغة العربية من 5 إلى 12)
  if (s.includes("اللغة العربية") || s === "عربي" || s.includes("عربية")) return "G5_12_ARABIC";

  // (اللغة الإنجليزية من 5 إلى 12)
  if (s.includes("اللغة الإنجليزية") || s.includes("انجليزي") || s.includes("إنجليزي") || s.includes("english"))
    return "G5_12_ENGLISH";

  if (s.includes("فيزياء")) return "G5_12_PHYSICS";
  if (s.includes("كيمياء")) return "G5_12_CHEMISTRY";
  if (s.includes("احياء") || s.includes("أحياء")) return "G5_12_BIOLOGY";

  if (s.includes("العلوم و البيئة") || s.includes("علوم و البيئة") || s.includes("العلوم والبيئة") || s.includes("البيئة"))
    return "G5_12_SCI_ENV";

  if (s.includes("الرياضة المدرسية") || s.includes("رياضة مدرسية") || s === "رياضة") return "G5_12_SPORTS";

  if (s.includes("الفنون التشكيلية") || s.includes("فنون تشكيلية") || s.includes("الفنون")) return "G5_12_ART";

  if (s.includes("المهارات الموسيقية") || s.includes("مهارات موسيقية") || s.includes("موسيقى")) return "G5_12_MUSIC";

  // (الدراسات الاجتماعية – التاريخ – هذا وطني – الجغرافيا من5 إلى 12)
  if (s.includes("الدراسات الاجتماعية") || s.includes("التاريخ") || s.includes("هذا وطني") || s.includes("الجغرافيا"))
    return "G5_12_SOCIAL";

  // (تقنية المعلومات من 5 إلى 12)
  if (s.includes("تقنية المعلومات") || s.includes("حاسوب") || s.includes("كمبيوتر") || s.includes("it")) return "G5_12_IT";

  return `G5_12_SUBJECT:${s}`;
}

// ✅ تطبيع "مطابقة مادة" للصفوف 1-4: لازم نفس النص (بعد trim/مسافات)
function normalizeExactSubject_1_4(subject: string) {
  return String(subject || "").trim().replace(/\s+/g, " ");
}

/* ============================================================
   ✅ السماح بفترتين (حسب كل الأيام أو تواريخ محددة)
============================================================ */
function isTwoPeriodsAllowedOnDate(dateISO: string, constraints: any): boolean {
  if (!constraints.allowTwoPeriodsSameDay) return false;
  if (constraints.allowTwoPeriodsSameDayAllDates) return true;
  const dates: string[] = Array.isArray(constraints.allowTwoPeriodsSameDayDates) ? constraints.allowTwoPeriodsSameDayDates : [];
  return dates.includes(dateISO);
}

/* ============================================================
   ✅ شرط: المعلم فاضي للمراجعة (subject1 فقط) + اليوم كامل
   ✅ + تطبيق ترحيل الجمعة/السبت إلى الأحد
============================================================ */
function buildDaySubjectsMap(exams: any[]) {
  const map = new Map<string, Set<string>>(); // workDateISO -> subjects set
  for (const e of exams || []) {
    const raw = String(e.dateISO || e.date || "").trim();
    const dateISO = workDateISO(raw); // ✅ ترحيل عطلة
    const subject = String(e.subject || "").trim();
    if (!dateISO || !subject) continue;
    if (!map.has(dateISO)) map.set(dateISO, new Set<string>());
    map.get(dateISO)!.add(subject);
  }
  return map;
}

/* ============================================================
   ✅ منطق التوزيع المحلي
============================================================ */
function runTaskDistributionLocal(params: { teachers: any[]; exams: any[]; constraints: any; runSeed?: number }) {
  const { teachers, exams, constraints, runSeed } = params;

  // ✅ تحميل عدم التوفر وبناء Index سريع للبحث
  const unavailIndex = buildUnavailabilityIndex(loadUnavailability());

  // ✅ حتى لا تكون خيارات الواجهة شكلية:
  const enableCorrectionFree = !!constraints?.freeAllSubjectTeachersForCorrection;

  // ✅ تفريغ التصحيح: ALL أو DATES (مع دعم القديم correctionFreeDateISO)
  const legacyOne = workDateISO(String(constraints?.correctionFreeDateISO || "").trim());
  const modeRaw = String(constraints?.correctionFreeMode || "").trim().toUpperCase();
  const correctionMode: "ALL" | "DATES" = modeRaw === "DATES" ? "DATES" : legacyOne ? "DATES" : "ALL";

  const selectedCorrectionDatesISO: string[] = (() => {
    const out: string[] = [];
    const arr = Array.isArray(constraints?.correctionFreeDatesISO) ? constraints.correctionFreeDatesISO : [];
    for (const d of arr) {
      const v = workDateISO(String(d || "").trim());
      if (v && !out.includes(v)) out.push(v);
    }
    if (legacyOne && !out.includes(legacyOne)) out.push(legacyOne);
    out.sort();
    return out;
  })();

  const teacherSubjectsAll = buildTeacherSubjectsMapAll(teachers);
  const teacherSubject1Map = buildTeacherSubject1Map(teachers);
  const daySubjectsMap = buildDaySubjectsMap(exams);

  const teacherNameMap = new Map<string, string>();
  let teacherIds: string[] = [];
  for (const t of teachers) {
    const id = String(t.id || "").trim();
    if (!id) continue;
    teacherIds.push(id);
    teacherNameMap.set(id, String(t.fullName || t.name || t.employeeNo || id).trim());
  }

  // ✅ shuffle
  const _seed = Number((runSeed ?? Date.now()) as any) || Date.now();
  teacherIds = seededShuffle(teacherIds, _seed);

  const maxTasks = Number(constraints.maxTasksPerTeacher ?? 10) || 10; // ✅ quota
  const reservePerPeriod = Number(constraints.reservePerPeriod ?? 0) || 0;
  const smartBySpecialty = !!constraints.smartBySpecialty;

  const quotaTotals = new Map<string, number>();
  const invCounts = new Map<string, number>();
  const occupiedSlots = new Map<string, Set<string>>(); // teacherId -> set(date__period)
  const dayHasAnyPeriod = new Map<string, Set<string>>(); // teacherId -> set(dateISO)
  const teacherDayFirstInvDuration = new Map<string, number>(); // key teacherId__dateISO -> durationMinutes of first invigilation

  // ✅ NEW: منع تكرار مراقبة 3 ساعات
  const teacherHad3HoursInv = new Map<string, boolean>(); // teacherId -> true إذا أخذ 180 دقيقة مرة

  teacherIds.forEach((id) => {
    quotaTotals.set(id, 0);
    invCounts.set(id, 0);
    occupiedSlots.set(id, new Set<string>());
    dayHasAnyPeriod.set(id, new Set<string>());
    teacherHad3HoursInv.set(id, false);
  });

  let rr = 0;
  const assignments: any[] = [];
  const unfilled: any[] = [];

  let invRequired = 0;
  let invAssigned = 0;
  let reserveRequired = 0;
  let reserveAssigned = 0;
  let reviewFreeTeachersDays = 0;
  let correctionFreeTeachersDays = 0;

  // ✅ REVIEW_FREE قبل توزيع المراقبة/الاحتياط (يُحسب ضمن النصاب)
  const reviewFreeApplied = new Set<string>(); // key teacherId__dateISO
  for (const [dateISO, subjectsSet] of daySubjectsMap.entries()) {
    for (const teacherId of teacherIds) {
      const s1 = String(teacherSubject1Map.get(teacherId) || "").trim();
      if (!s1) continue;
      if (!subjectsSet.has(s1)) continue;

      const key = `${teacherId}__${dateISO}`;
      if (reviewFreeApplied.has(key)) continue;

      if ((quotaTotals.get(teacherId) || 0) >= maxTasks) continue;

      occupiedSlots.get(teacherId)!.add(slotKey(dateISO, "AM"));
      occupiedSlots.get(teacherId)!.add(slotKey(dateISO, "PM"));
      dayHasAnyPeriod.get(teacherId)!.add(dateISO);

      quotaTotals.set(teacherId, (quotaTotals.get(teacherId) || 0) + 1);

      assignments.push({
        teacherId,
        teacherName: teacherNameMap.get(teacherId) || teacherId,
        taskType: "REVIEW_FREE",
        taskTypeLabelAr: TASK_TYPE_LABEL_AR["REVIEW_FREE"],
        dateISO,
        date: dateISO,
        period: "AM",
        subject: s1,
        fullDay: true,
        coversPeriods: ["AM", "PM"],
        reviewBySubject1Only: true,
      });

      reviewFreeApplied.add(key);
      reviewFreeTeachersDays += 1;
    }
  }

  // ============================================================
  // ✅ NEW: تحديد آخر يوم اختبار + آخر يومين (بعد ترحيل عطلة الجمعة/السبت)
  // ============================================================
  const _uniqueWorkExamDates0 = Array.from(
    new Set(
      (exams || [])
        .map((e: any) => workDateISO(String(e.dateISO || e.date || "").trim()))
        .filter(Boolean)
    )
  ).sort();

  const _lastExamDate0 = _uniqueWorkExamDates0.length ? _uniqueWorkExamDates0[_uniqueWorkExamDates0.length - 1] : "";

  const _lastTwoExamDates0 = new Set<string>();
  if (_uniqueWorkExamDates0.length >= 1) _lastTwoExamDates0.add(_uniqueWorkExamDates0[_uniqueWorkExamDates0.length - 1]);
  if (_uniqueWorkExamDates0.length >= 2) _lastTwoExamDates0.add(_uniqueWorkExamDates0[_uniqueWorkExamDates0.length - 2]);

  // ============================================================
  // ✅ PRE-COMPUTE CORRECTION DAYS (BEFORE distribution)
  // ✅ (اليوم التالي فقط) + (تمييز 1-4 عن 5-12)
  // ============================================================
  const sortedExams = [...exams].sort((a, b) => {
    const da = workDateISO(String(a.dateISO || a.date || ""));
    const db = workDateISO(String(b.dateISO || b.date || ""));
    if (da !== db) return da.localeCompare(db);
    const pa = periodToAMPM(String(a.period || ""));
    const pb = periodToAMPM(String(b.period || ""));
    return pa === pb ? 0 : pa === "AM" ? -1 : 1;
  });

  // ✅ teacherExactSubjects_1_4: مطابقة نصية للمادة (للصفوف 1-4)
  // ✅ teacherGroups_5_12: مفاتيح مجموعات التصحيح (للصفوف 5-12)
  const teacherExactSubjects_1_4 = new Map<string, Set<string>>(); // teacherId -> Set(exact normalized subject strings)
  const teacherGroups_5_12 = new Map<string, Set<string>>(); // teacherId -> Set(groupKey)

  for (const t of teachers) {
    const teacherId = String(t.id || "").trim();
    if (!teacherId) continue;

    const exactSet = new Set<string>();
    const groupsSet = new Set<string>();

    [t.subject1, t.subject2, t.subject3, t.subject4]
      .map((x: any) => String(x ?? "").trim())
      .filter(Boolean)
      .forEach((s) => {
        exactSet.add(normalizeExactSubject_1_4(s));
        groupsSet.add(getCorrectionGroupKey_5_12(s));
      });

    teacherExactSubjects_1_4.set(teacherId, exactSet);
    teacherGroups_5_12.set(teacherId, groupsSet);
  }

  const teacherCorrectionDays = new Map<string, Set<string>>(); // teacherId -> Set(correctionDateISO)

  // ✅ تفريغ التصحيح (اختياري حسب خيار الواجهة)
  if (enableCorrectionFree) {
    for (const exam of sortedExams) {
      const examDateISO_raw = String(exam.dateISO || exam.date || "").trim();
      const examDateISO = workDateISO(examDateISO_raw); // ✅ ترحيل عطلة
      const subject = String(exam.subject || "").trim();
      if (!examDateISO || !subject) continue;

      const grade = extractGradeFromSubject(subject);
      const correctionDateISO = workDateISO(addDaysISO(examDateISO, 1)); // ✅ اليوم التالي فقط + ترحيل عطلة

      // ✅ NEW: إذا كان الوضع DATES نطبّق التفريغ على الأيام المحددة فقط
      if (correctionMode === "DATES") {
        if (!selectedCorrectionDatesISO.length) continue; // لا توجد أيام مختارة → لا تفريغ
        if (!selectedCorrectionDatesISO.includes(correctionDateISO)) continue;
      }

      // ✅ لا نسمح بتصحيح يتعارض مع REVIEW_FREE
      // (نحتفظ بنفس سلوكك السابق)
      for (const teacherId of teacherIds) {
        if (reviewFreeApplied.has(`${teacherId}__${correctionDateISO}`)) continue;

        const ok =
          grade !== null && grade >= 1 && grade <= 4
            ? // ✅ 1-4: مطابقة نصية للمادة مع أي subject1..4
              (teacherExactSubjects_1_4.get(teacherId) || new Set<string>()).has(normalizeExactSubject_1_4(subject))
            : // ✅ 5-12 (أو غير معلوم): حسب المجموعات
              (teacherGroups_5_12.get(teacherId) || new Set<string>()).has(getCorrectionGroupKey_5_12(subject));

        if (!ok) continue;

        if (!teacherCorrectionDays.has(teacherId)) teacherCorrectionDays.set(teacherId, new Set<string>());
        teacherCorrectionDays.get(teacherId)!.add(correctionDateISO);
      }
    }
  }

  function canAssign(
    teacherId: string,
    dateISO: string,
    period: "AM" | "PM",
    taskType: string,
    subject: string,
    meta?: any
  ) {
    if (!teacherId) return { ok: false, reason: "NO_TEACHERS" as const };

    // ✅ عدم التوفر (يمنع حسب اليوم+الفترة+نوع المهمة)
    if (
      (taskType === "INVIGILATION" ||
        taskType === "RESERVE" ||
        taskType === "REVIEW_FREE" ||
        taskType === "CORRECTION_FREE") &&
      isTeacherUnavailable({
        teacherId,
        dateISO,
        period,
        taskType: taskType as any,
        index: unavailIndex,
      })
    ) {
      return { ok: false, reason: "UNAVAILABLE" as const };
    }

    const tQuota = quotaTotals.get(teacherId) || 0;
    if (tQuota >= maxTasks) return { ok: false, reason: "MAX_TASKS_REACHED" as const };

    const sk = slotKey(dateISO, period);
    const slots = occupiedSlots.get(teacherId) || new Set<string>();
    if (slots.has(sk)) return { ok: false, reason: "PERIOD_CONFLICT" as const };

    // ✅ منع أي مهام في يوم التصحيح (اليوم التالي فقط)
    if (enableCorrectionFree) {
      const corDays = teacherCorrectionDays.get(teacherId);
      if (corDays && corDays.has(dateISO)) {
        return { ok: false, reason: "CORRECTION_FREE_BLOCK" as const };
      }
    }

    // ✅ NEW: شرط 13 / 14 على آخر يوم/آخر يومين (نمنع التوزيع للمراقبة/الاحتياط فقط)
    const tName = teacherNameMap.get(teacherId) || "";
    if (taskType === "INVIGILATION" || taskType === "RESERVE") {
      if (_lastExamDate0 && teacherHas13(tName) && dateISO === _lastExamDate0) {
        return { ok: false, reason: "BACK_TO_BACK_BLOCK" as const };
      }
      if (_lastTwoExamDates0.size && teacherHas14(tName) && _lastTwoExamDates0.has(dateISO)) {
        return { ok: false, reason: "BACK_TO_BACK_BLOCK" as const };
      }
    }

    // ✅ NEW: منع تكرار مراقبة 3 ساعات لنفس المعلم
    if (taskType === "INVIGILATION") {
      const dur = Number(meta?.durationMinutes ?? 0) || 0;
      if (dur === 180 && (teacherHad3HoursInv.get(teacherId) || false)) {
        return { ok: false, reason: "BACK_TO_BACK_BLOCK" as const };
      }
    }

    // ✅ منع فترتين لنفس المعلم في نفس اليوم افتراضيًا
    {
      const datesSet = dayHasAnyPeriod.get(teacherId) || new Set<string>();
      const slotsAny = occupiedSlots.get(teacherId) || new Set<string>();
      const hasSameDay = datesSet.has(dateISO) || Array.from(slotsAny).some((x) => x.startsWith(`${dateISO}__`));
      if (hasSameDay) {
        const allowedGlobal = isTwoPeriodsAllowedOnDate(dateISO, constraints);
        if (!allowedGlobal) {
          return { ok: false, reason: "BACK_TO_BACK_BLOCK" as const };
        }
      }
    }

    if (smartBySpecialty && taskType === "INVIGILATION") {
      const subs = teacherSubjectsAll.get(teacherId);
      if (subs && subs.has(String(subject || "").trim())) return { ok: false, reason: "SPECIALTY_BLOCK" as const };
    }

    return { ok: true as const };
  }

  function commitAssign(
    teacherId: string,
    dateISO: string,
    period: "AM" | "PM",
    taskType: string,
    subject: string,
    meta?: any
  ) {
    const sk = slotKey(dateISO, period);
    occupiedSlots.get(teacherId)!.add(sk);
    dayHasAnyPeriod.get(teacherId)!.add(dateISO);

    if (isQuotaTaskType(taskType)) {
      quotaTotals.set(teacherId, (quotaTotals.get(teacherId) || 0) + 1);
    }

    if (taskType === "INVIGILATION") {
      invCounts.set(teacherId, (invCounts.get(teacherId) || 0) + 1);

      const dur = Number(meta?.durationMinutes ?? 0) || 0;

      const key = `${teacherId}__${dateISO}`;
      if (!teacherDayFirstInvDuration.has(key)) {
        if (dur > 0) teacherDayFirstInvDuration.set(key, dur);
      }

      // ✅ NEW: إذا أخذ 3 ساعات مرة، امنع تكرارها لاحقًا
      if (dur === 180) {
        teacherHad3HoursInv.set(teacherId, true);
      }
    }

    assignments.push({
      teacherId,
      teacherName: teacherNameMap.get(teacherId) || teacherId,
      taskType,
      taskTypeLabelAr: TASK_TYPE_LABEL_AR[taskType] || "غير محدد",
      dateISO,
      date: dateISO,
      period,
      subject,
      ...meta,
    });
  }

  // ✅ توزيع: INVIGILATION بالحد الأدنى من المراقبات، والباقي RR
  function assignOne(dateISO: string, period: "AM" | "PM", taskType: string, subject: string, meta?: any) {
    const n = teacherIds.length;
    if (n === 0) return { assigned: false as const, reason: "NO_TEACHERS" as const };

    if (taskType === "INVIGILATION") {
      const start = rr;

      const subj12 = subjectHas12(subject);

      const baseCandidates = teacherIds
        .map((id, idx) => {
          const slotsSet = occupiedSlots.get(id) || new Set<string>();
          const hasSameDay =
            (dayHasAnyPeriod.get(id) || new Set<string>()).has(dateISO) ||
            Array.from(slotsSet).some((x) => x.startsWith(`${dateISO}__`));
          const firstDur = teacherDayFirstInvDuration.get(`${id}__${dateISO}`) ?? 999999;

          const name = teacherNameMap.get(id) || "";
          const is12 = teacherHas12(name);

          return {
            id,
            idx,
            inv: invCounts.get(id) || 0,
            quota: quotaTotals.get(id) || 0,
            rrDist: (idx - start + n) % n,
            hasSameDay,
            firstDur,
            is12,
          };
        })
        .sort(
          (a, b) =>
            // ✅ NEW: لو مادة 12، فضّل معلم 12
            (subj12 ? Number(b.is12) - Number(a.is12) : 0) ||
            a.inv - b.inv ||
            a.quota - b.quota ||
            Number(a.hasSameDay) - Number(b.hasSameDay) ||
            a.firstDur - b.firstDur ||
            a.rrDist - b.rrDist
        );

      const hasAny12 = subj12 && baseCandidates.some((c) => c.is12);
      const ordered = hasAny12
        ? [...baseCandidates.filter((c) => c.is12), ...baseCandidates.filter((c) => !c.is12)]
        : baseCandidates;

      for (const c of ordered) {
        const chk = canAssign(c.id, dateISO, period, taskType, subject, meta);
        if (!chk.ok) continue;

        commitAssign(c.id, dateISO, period, taskType, subject, meta);
        rr = (c.idx + 1) % n;
        return { assigned: true as const };
      }

      return { assigned: false as const, reason: "NO_TEACHERS" as const };
    }

    for (let tries = 0; tries < n; tries++) {
      const idx = (rr + tries) % n;
      const teacherId = teacherIds[idx];
      const chk = canAssign(teacherId, dateISO, period, taskType, subject, meta);
      if (!chk.ok) continue;

      commitAssign(teacherId, dateISO, period, taskType, subject, meta);
      rr = (idx + 1) % n;
      return { assigned: true as const };
    }

    return { assigned: false as const, reason: "NO_TEACHERS" as const };
  }

  // ============================================================
  // ✅ PASS 1: توزيع المراقبة لكل الامتحانات أولاً
  // ✅ PASS 2: توزيع الاحتياط بعد الانتهاء من المراقبة
  // ✅ شرط: إذا حصل عجز مراقبة في يوم => لا يتم توزيع احتياط في هذا اليوم بالكامل
  // ============================================================

  const examSlots = new Map<string, { dateISO: string; period: "AM" | "PM"; subjects: string[]; examIds: string[] }>();
  for (const exam of sortedExams) {
    const dateISO = workDateISO(String(exam.dateISO || exam.date || "").trim()); // ✅ ترحيل عطلة
    const period = periodToAMPM(String(exam.period || ""));
    const subject = String(exam.subject || "").trim();
    if (!dateISO || !subject) continue;

    const sk = slotKey(dateISO, period);
    if (!examSlots.has(sk)) examSlots.set(sk, { dateISO, period, subjects: [], examIds: [] });
    examSlots.get(sk)!.subjects.push(subject);
    examSlots.get(sk)!.examIds.push(String(exam.id || ""));
  }

  const daysWithInvShortage = new Set<string>();

  // ----- PASS 1: INVIGILATION (مع شرط "بن" + شروط 12/13/14/3س) -----
  for (const exam of sortedExams) {
    const rawDate = String(exam.dateISO || exam.date || "").trim();
    const dateISO = workDateISO(rawDate); // ✅ ترحيل الجمعة/السبت إلى الأحد
    const period = periodToAMPM(String(exam.period || ""));
    const subject = String(exam.subject || "").trim();
    const roomsCount = Number(exam.roomsCount || 0) || 0;

    if (!dateISO || !subject) continue;

    const invPerRoom = Math.max(1, Number(guessInvigilatorsPerRoom(exam, constraints) || 1));
    const neededInv = roomsCount * invPerRoom;
    invRequired += neededInv;

    let assignedInvHere = 0;

    for (let committeeNo = 1; committeeNo <= roomsCount; committeeNo++) {
      // ============ حالة 1 مراقب في اللجنة ============
      if (invPerRoom === 1) {
        const n = teacherIds.length;
        const start = rr;
        const subj12 = subjectHas12(subject);

        const candidatesAll = teacherIds
          .map((id, idx) => {
            const slotsSet = occupiedSlots.get(id) || new Set<string>();
            const hasSameDay =
              (dayHasAnyPeriod.get(id) || new Set<string>()).has(dateISO) ||
              Array.from(slotsSet).some((x) => x.startsWith(`${dateISO}__`));
            const firstDur = teacherDayFirstInvDuration.get(`${id}__${dateISO}`) ?? 999999;
            const name = teacherNameMap.get(id) || "";
            return {
              id,
              idx,
              inv: invCounts.get(id) || 0,
              quota: quotaTotals.get(id) || 0,
              rrDist: (idx - start + n) % n,
              hasSameDay,
              firstDur,
              name,
              ben: hasBenInName(name),
              is12: teacherHas12(name),
            };
          })
          .filter((c) => c.ben) // ✅ شرط: لازم "بن"
          .sort(
            (a, b) =>
              (subj12 ? Number(b.is12) - Number(a.is12) : 0) ||
              a.inv - b.inv ||
              a.quota - b.quota ||
              Number(a.hasSameDay) - Number(b.hasSameDay) ||
              a.firstDur - b.firstDur ||
              a.rrDist - b.rrDist
          );

        const hasAny12 = subj12 && candidatesAll.some((c) => c.is12);
        const candidates = hasAny12
          ? [...candidatesAll.filter((c) => c.is12), ...candidatesAll.filter((c) => !c.is12)]
          : candidatesAll;

        let ok = false;
        for (const c of candidates) {
          const chk = canAssign(c.id, dateISO, period, "INVIGILATION", subject, {
            durationMinutes: Number(exam.durationMinutes ?? 0) || 0,
          });
          if (!chk.ok) continue;

          commitAssign(c.id, dateISO, period, "INVIGILATION", subject, {
            examId: exam.id,
            examSubject: subject,
            committeeNo,
            committeeNumber: committeeNo,
            roomNo: committeeNo,
            roomNumber: committeeNo,
            invigilatorIndex: 1,
            durationMinutes: Number(exam.durationMinutes ?? 0) || 0,
          });

          rr = (c.idx + 1) % n;
          ok = true;
          assignedInvHere += 1;
          invAssigned += 1;
          break;
        }

        if (!ok) {
          daysWithInvShortage.add(dateISO);
          unfilled.push({
            kind: "INVIGILATION",
            dateISO,
            period,
            subject,
            required: neededInv,
            assigned: assignedInvHere,
            reasons: [{ code: "NO_TEACHERS", count: 1 }],
          });
          break;
        }

        continue;
      }

      // ============ حالة 2 مراقبين في اللجنة ============
      if (invPerRoom === 2) {
        const n = teacherIds.length;
        const start = rr;
        const subj12 = subjectHas12(subject);

        const buildCandidates = () =>
          teacherIds
            .map((id, idx) => {
              const slotsSet = occupiedSlots.get(id) || new Set<string>();
              const hasSameDay =
                (dayHasAnyPeriod.get(id) || new Set<string>()).has(dateISO) ||
                Array.from(slotsSet).some((x) => x.startsWith(`${dateISO}__`));
              const firstDur = teacherDayFirstInvDuration.get(`${id}__${dateISO}`) ?? 999999;
              const name = teacherNameMap.get(id) || "";
              return {
                id,
                idx,
                inv: invCounts.get(id) || 0,
                quota: quotaTotals.get(id) || 0,
                rrDist: (idx - start + n) % n,
                hasSameDay,
                firstDur,
                name,
                ben: hasBenInName(name),
                is12: teacherHas12(name),
              };
            })
            .sort(
              (a, b) =>
                (subj12 ? Number(b.is12) - Number(a.is12) : 0) ||
                a.inv - b.inv ||
                a.quota - b.quota ||
                Number(a.hasSameDay) - Number(b.hasSameDay) ||
                a.firstDur - b.firstDur ||
                a.rrDist - b.rrDist
            );

        let firstPicked: any = null;
        let secondPicked: any = null;

        let cand1 = buildCandidates();
        if (subj12) {
          const any12 = cand1.some((c) => c.is12);
          if (any12) cand1 = [...cand1.filter((c) => c.is12), ...cand1.filter((c) => !c.is12)];
        }

        for (const c1 of cand1) {
          const chk1 = canAssign(c1.id, dateISO, period, "INVIGILATION", subject, {
            durationMinutes: Number(exam.durationMinutes ?? 0) || 0,
          });
          if (!chk1.ok) continue;

          const cand2raw = buildCandidates().filter((c2) => c2.id !== c1.id);
          const cand2 = subj12
            ? [...cand2raw.filter((c) => c.is12), ...cand2raw.filter((c) => !c.is12)]
            : cand2raw;

          for (const c2 of cand2) {
            // ✅ ممنوع: بدون بن + بدون بن
            if (!c1.ben && !c2.ben) continue;

            const chk2 = canAssign(c2.id, dateISO, period, "INVIGILATION", subject, {
              durationMinutes: Number(exam.durationMinutes ?? 0) || 0,
            });
            if (!chk2.ok) continue;

            firstPicked = c1;
            secondPicked = c2;
            break;
          }
          if (firstPicked && secondPicked) break;
        }

        if (!firstPicked || !secondPicked) {
          daysWithInvShortage.add(dateISO);
          unfilled.push({
            kind: "INVIGILATION",
            dateISO,
            period,
            subject,
            required: neededInv,
            assigned: assignedInvHere,
            reasons: [{ code: "NO_TEACHERS", count: 1 }],
          });
          break;
        }

        commitAssign(firstPicked.id, dateISO, period, "INVIGILATION", subject, {
          examId: exam.id,
          examSubject: subject,
          committeeNo,
          committeeNumber: committeeNo,
          roomNo: committeeNo,
          roomNumber: committeeNo,
          invigilatorIndex: 1,
          durationMinutes: Number(exam.durationMinutes ?? 0) || 0,
        });
        assignedInvHere += 1;
        invAssigned += 1;

        commitAssign(secondPicked.id, dateISO, period, "INVIGILATION", subject, {
          examId: exam.id,
          examSubject: subject,
          committeeNo,
          committeeNumber: committeeNo,
          roomNo: committeeNo,
          roomNumber: committeeNo,
          invigilatorIndex: 2,
          durationMinutes: Number(exam.durationMinutes ?? 0) || 0,
        });
        assignedInvHere += 1;
        invAssigned += 1;

        rr = (secondPicked.idx + 1) % n;
        continue;
      }

      // ============ أكثر من 2 مراقب في اللجنة: توزيع عادي ============
      for (let j = 1; j <= invPerRoom; j++) {
        const res = assignOne(dateISO, period, "INVIGILATION", subject, {
          examId: exam.id,
          examSubject: subject,
          committeeNo,
          committeeNumber: committeeNo,
          roomNo: committeeNo,
          roomNumber: committeeNo,
          invigilatorIndex: j,
          durationMinutes: Number(exam.durationMinutes ?? 0) || 0,
        });
        if (res.assigned) {
          assignedInvHere += 1;
          invAssigned += 1;
        } else {
          daysWithInvShortage.add(dateISO);
          unfilled.push({
            kind: "INVIGILATION",
            dateISO,
            period,
            subject,
            required: neededInv,
            assigned: assignedInvHere,
            reasons: [{ code: res.reason || "NO_TEACHERS", count: 1 }],
          });
          break;
        }
      }
    }
  }

  // ----- PASS 2: RESERVE -----
  for (const slot of Array.from(examSlots.values()).sort((a, b) => {
    if (a.dateISO !== b.dateISO) return a.dateISO.localeCompare(b.dateISO);
    return a.period === b.period ? 0 : a.period === "AM" ? -1 : 1;
  })) {
    const { dateISO, period, subjects, examIds } = slot;

    if (daysWithInvShortage.has(dateISO)) continue;

    reserveRequired += reservePerPeriod;

    let assignedResHere = 0;
    for (let i = 0; i < reservePerPeriod; i++) {
      const labelSubject = subjects?.[0] ? String(subjects[0]) : "احتياط";
      const res = assignOne(dateISO, period, "RESERVE", labelSubject, {
        examId: examIds?.[0] || "",
        examIds,
        slotSubjects: subjects,
      });
      if (res.assigned) {
        assignedResHere += 1;
        reserveAssigned += 1;
      } else {
        unfilled.push({
          kind: "RESERVE",
          dateISO,
          period,
          subject: subjects?.[0] || "",
          required: reservePerPeriod,
          assigned: assignedResHere,
          reasons: [{ code: res.reason || "NO_TEACHERS", count: 1 }],
        });
        break;
      }
    }
  }

  // ============================================================
  // ✅ APPLY CORRECTION_FREE (AFTER distribution)
  // ✅ (اليوم التالي فقط) ✅ بدون أي ترحيل/shift
  // ✅ التصحيح لا يدخل في النصاب
  // ============================================================
  const correctionApplied = new Set<string>(); // key teacherId__dateISO
  const appliedCorrectionDaysByTeacher = new Map<string, Set<string>>();

  function isTeacherFreeFullDay(teacherId: string, dateISO: string) {
    const key = `${teacherId}__${dateISO}`;
    if (reviewFreeApplied.has(key)) return false;
    const set = occupiedSlots.get(teacherId) || new Set<string>();
    return !set.has(slotKey(dateISO, "AM")) && !set.has(slotKey(dateISO, "PM"));
  }

  if (enableCorrectionFree) {
    for (const teacherId of teacherIds) {
      const daysSet = teacherCorrectionDays.get(teacherId);
      if (!daysSet || daysSet.size === 0) continue;

      for (const correctionDateISO_raw of Array.from(daysSet).sort()) {
        const correctionDateISO = workDateISO(correctionDateISO_raw);
        const key = `${teacherId}__${correctionDateISO}`;
        if (correctionApplied.has(key)) continue;

        // ✅ بدون shift: إذا لم يكن فاضي (نادرًا بسبب قيود أخرى)، نتجاهل ونترك تحذير ضمن warnings لاحقًا
        if (!isTeacherFreeFullDay(teacherId, correctionDateISO)) {
          // لا نرحّل أبداً
          continue;
        }

        occupiedSlots.get(teacherId)!.add(slotKey(correctionDateISO, "AM"));
        occupiedSlots.get(teacherId)!.add(slotKey(correctionDateISO, "PM"));
        dayHasAnyPeriod.get(teacherId)!.add(correctionDateISO);

        assignments.push({
          teacherId,
          teacherName: teacherNameMap.get(teacherId) || teacherId,
          taskType: "CORRECTION_FREE",
          taskTypeLabelAr: TASK_TYPE_LABEL_AR["CORRECTION_FREE"],
          dateISO: correctionDateISO,
          date: correctionDateISO,
          period: "AM",
          subject: "تصحيح",
          fullDay: true,
          coversPeriods: ["AM", "PM"],
          correctionDays: 1,
          basedOnExamTableOnly: true,
          correctionFixedNextDayOnly: true,
        });

        correctionApplied.add(key);
        correctionFreeTeachersDays += 1;

        if (!appliedCorrectionDaysByTeacher.has(teacherId)) appliedCorrectionDaysByTeacher.set(teacherId, new Set<string>());
        appliedCorrectionDaysByTeacher.get(teacherId)!.add(correctionDateISO);
      }
    }
  }

  const correctionByTeacher = enableCorrectionFree
    ? teacherIds
        .map((teacherId) => {
          const dates = Array.from(appliedCorrectionDaysByTeacher.get(teacherId) || []).sort();
          return {
            teacherId,
            teacherName: teacherNameMap.get(teacherId) || teacherId,
            correctionDates: dates,
            correctionDaysCount: dates.length,
          };
        })
        .filter((x) => x.correctionDaysCount > 0)
        .sort((a, b) => b.correctionDaysCount - a.correctionDaysCount || a.teacherName.localeCompare(b.teacherName, "ar"))
    : [];

  // ============================================================
  // ✅ NEW: اقتراح يوم بديل للتصحيح إذا كان هناك عجز في المراقبة
  // عند اختيار يوم تصحيح محدد (correctionFreeDateISO)
  // ============================================================
  function suggestBetterCorrectionDate(fromDateISO: string) {
    const workExamDates = new Set<string>();
    for (const e of exams || []) {
      const d = workDateISO(String(e.dateISO || e.date || "").trim());
      if (d) workExamDates.add(d);
    }

    // نبحث عن أول يوم عمل بعد التاريخ المختار لا يوجد فيه امتحانات (أفضل لتجنب العجز)
    for (let i = 1; i <= 14; i++) {
      const cand = workDateISO(addDaysISO(fromDateISO, i));
      if (!cand) continue;
      if (!workExamDates.has(cand)) return cand;
    }

    // fallback
    return workDateISO(addDaysISO(fromDateISO, 1));
  }

  const correctionSelectedDates = correctionMode === "DATES" ? selectedCorrectionDatesISO : [];

  const invShortageOnSelectedCorrectionDates: Record<string, number> = {};
  if (correctionSelectedDates.length) {
    for (const d of correctionSelectedDates) {
      const shortage = unfilled
        .filter((u) => u?.kind === "INVIGILATION" && String(u?.dateISO || "").trim() === d)
        .reduce((acc, u) => acc + Math.max(0, Number(u?.required || 0) - Number(u?.assigned || 0)), 0);
      if (shortage > 0) invShortageOnSelectedCorrectionDates[d] = shortage;
    }
  }

  const suggestedCorrectionDates: Record<string, string> = {};
  for (const d of Object.keys(invShortageOnSelectedCorrectionDates)) {
    suggestedCorrectionDates[d] = suggestBetterCorrectionDate(d);
  }

  const out: any = {
    assignments,
    warnings: [],
    debug: {
      summary: {
        invRequired,
        invAssigned,
        reserveRequired,
        reserveAssigned,
        reviewFreeTeachersDays,
        correctionFreeTeachersDays,
        teachersTotal: teachers.length,
        examsTotal: exams.length,
        runSeed: _seed,
        daysNoReserveBecauseInvShortage: Array.from(daysWithInvShortage).sort(),

        // ✅ NEW: معلومات تفريغ التصحيح (اليوم المحدد + اقتراح بديل عند العجز)
        correctionFreeMode: correctionMode,
        correctionFreeSelectedDatesISO: correctionSelectedDates,
        correctionFreeInvShortageByDate: invShortageOnSelectedCorrectionDates,
        correctionFreeSuggestedDatesByDate: suggestedCorrectionDates,
      },
      unfilled,
      correctionByTeacher,
    },
  };

  // ✅ تحذيرات واضحة للمستخدم في حال وجود عجز في أي تاريخ من تواريخ التفريغ
  for (const d of Object.keys(suggestedCorrectionDates)) {
    const alt = suggestedCorrectionDates[d];
    if (!alt) continue;
    out.warnings.push(
      `⚠️ يوجد عجز في المراقبة بتاريخ ${d} بسبب تفريغ معلمي المادة للتصحيح. اقترح نقل يوم التصحيح إلى ${alt}.`
    );
  }

  return out;
}

/* ============================================================
   ✅ عند وجود عجز في المراقبة يأخذ من الاحتياط (Post-Run)
============================================================ */
function rebalanceReserveToCoverInvigilations(out: any, latestTeachers: any[], constraints: any) {
  const debug = out?.debug;
  const assigns: any[] = Array.isArray(out?.assignments) ? out.assignments : [];
  const unfilled: any[] = Array.isArray(debug?.unfilled) ? debug.unfilled : [];
  if (!assigns.length || !unfilled.length) return out;

  const teacherSubjectsMapAll = buildTeacherSubjectsMapAll(latestTeachers);
  const smartBySpecialty = !!constraints?.smartBySpecialty;

  function canConvert(teacherId: string, examSubject: string) {
    if (!smartBySpecialty) return true;
    const subs = teacherSubjectsMapAll.get(teacherId);
    if (!subs) return true;
    return !subs.has(String(examSubject || "").trim());
  }

  const invShortages = unfilled.filter((u) => u?.kind === "INVIGILATION" && Number(u?.required || 0) > Number(u?.assigned || 0));
  if (!invShortages.length) return out;

  const usedReserveIdx = new Set<number>();

  for (const u of invShortages) {
    const dateISO = String(u?.dateISO || "").trim();
    const period = String(u?.period || "").trim();
    const subject = String(u?.subject || "").trim();

    let need = Number(u.required || 0) - Number(u.assigned || 0);
    if (!dateISO || !period || need <= 0) continue;

    const reserveCandidates = assigns
      .map((a, idx) => ({ a, idx }))
      .filter(({ a, idx }) => {
        if (usedReserveIdx.has(idx)) return false;
        if (String(a?.taskType || "") !== "RESERVE") return false;
        const aDate = String(a?.dateISO || a?.date || "").trim();
        const aPeriod = String(a?.period || "").trim();
        return aDate === dateISO && aPeriod === period;
      });

    for (const { a, idx } of reserveCandidates) {
      if (need <= 0) break;

      const teacherId = String(a?.teacherId || "").trim();
      if (!teacherId) continue;
      if (subject && !canConvert(teacherId, subject)) continue;

      a.taskType = "INVIGILATION";
      a.taskTypeLabelAr = TASK_TYPE_LABEL_AR["INVIGILATION"];
      if (!a.subject && subject) a.subject = subject;
      a.__convertedFromReserve = true;

      usedReserveIdx.add(idx);
      need -= 1;

      if (debug?.summary) {
        if (typeof debug.summary.invAssigned === "number") debug.summary.invAssigned += 1;
        if (typeof debug.summary.reserveAssigned === "number") debug.summary.reserveAssigned -= 1;
      }
      u.assigned = Number(u.assigned || 0) + 1;
    }
  }

  return out;
}

/* ============================================================
   ✅ التوازن في التوزيع – نقل بعض مهام (مراقبة/احتياط)
============================================================ */
function buildTeacherMetaMaps(teachers: any[]) {
  const nameMap = new Map<string, string>();
  const subjectsMapAll = new Map<string, Set<string>>();

  for (const t of teachers || []) {
    const id = String(t.id ?? "").trim();
    if (!id) continue;

    nameMap.set(id, String(t.fullName || t.name || t.employeeNo || id).trim());

    const subs = new Set<string>();
    [t.subject1, t.subject2, t.subject3, t.subject4].forEach((s: any) => {
      const v = String(s ?? "").trim();
      if (v) subs.add(v);
    });
    subjectsMapAll.set(id, subs);
  }

  return { nameMap, subjectsMapAll };
}

function slotKeyOf(a: any) {
  const dateISO = String(a?.dateISO || a?.date || "").trim();
  const period = String(a?.period || "").trim();
  return `${dateISO}__${period}`;
}

function isTeacherReviewFreeFullDay(assigns: any[], teacherId: string, dateISO: string) {
  return assigns.some((a) => {
    if (String(a?.teacherId || "") !== teacherId) return false;
    if (String(a?.taskType || "") !== "REVIEW_FREE") return false;
    const d = String(a?.dateISO || a?.date || "").trim();
    return d === dateISO && !!a?.fullDay;
  });
}

function canTakeAssignment(params: {
  teacherId: string;
  a: any;
  constraints: any;
  teacherSubjectsMapAll: Map<string, Set<string>>;
  teacherSlotSet: Map<string, Set<string>>;
  teacherQuotaTotals: Map<string, number>;
  assignsAll: any[];
}) {
  const { teacherId, a, constraints, teacherSubjectsMapAll, teacherSlotSet, teacherQuotaTotals, assignsAll } = params;

  const maxTasks = Number(constraints?.maxTasksPerTeacher ?? 10) || 10;
  const currentQuota = teacherQuotaTotals.get(teacherId) || 0;
  if (currentQuota >= maxTasks) return false;

  const dateISO = String(a?.dateISO || a?.date || "").trim();
  if (dateISO && isTeacherReviewFreeFullDay(assignsAll, teacherId, dateISO)) return false;

  const sk = slotKeyOf(a);
  if (!sk || sk.startsWith("__")) return false;

  const slots = teacherSlotSet.get(teacherId) || new Set<string>();
  if (slots.has(sk)) return false;

  const smartBySpecialty = !!constraints?.smartBySpecialty;
  const type = String(a?.taskType || "").trim();

  if (smartBySpecialty && type === "INVIGILATION") {
    const subj = String(a?.subject || "").trim();
    if (subj) {
      const subs = teacherSubjectsMapAll.get(teacherId);
      if (subs && subs.has(subj)) return false;
    }
  }

  if (dateISO) {
    const allowed = isTwoPeriodsAllowedOnDate(dateISO, constraints);
    const existing = Array.from(slots).some((x) => x.startsWith(`${dateISO}__`));
    if (existing && !allowed) return false;
  }

  return true;
}

function rebalanceFairDistribution(out: any, latestTeachers: any[], constraints: any) {
  const assigns: any[] = Array.isArray(out?.assignments) ? out.assignments : [];
  if (!assigns.length) return out;

  const { nameMap, subjectsMapAll } = buildTeacherMetaMaps(latestTeachers);

  const teacherQuotaTotals = new Map<string, number>();
  const teacherSlotSet = new Map<string, Set<string>>();

  function bumpQuota(teacherId: string, delta: number) {
    teacherQuotaTotals.set(teacherId, (teacherQuotaTotals.get(teacherId) || 0) + delta);
  }
  function addSlot(teacherId: string, sk: string) {
    const set = teacherSlotSet.get(teacherId) || new Set<string>();
    set.add(sk);
    teacherSlotSet.set(teacherId, set);
  }
  function removeSlot(teacherId: string, sk: string) {
    const set = teacherSlotSet.get(teacherId);
    if (set) set.delete(sk);
  }

  for (const t of latestTeachers || []) {
    const id = String(t.id ?? "").trim();
    if (id) {
      teacherQuotaTotals.set(id, 0);
      teacherSlotSet.set(id, new Set<string>());
    }
  }

  for (const a of assigns) {
    const teacherId = String(a?.teacherId || "").trim();
    if (!teacherId) continue;

    const sk = slotKeyOf(a);
    if (sk && !sk.startsWith("__")) addSlot(teacherId, sk);

    const tt = String(a?.taskType || "").trim();
    if (isQuotaTaskType(tt)) bumpQuota(teacherId, 1);
  }

  const teacherIds = Array.from(teacherQuotaTotals.keys());
  if (teacherIds.length <= 1) return out;

  const movable = assigns
    .map((a, idx) => ({ a, idx }))
    .filter(({ a }) => {
      const tt = String(a?.taskType || "").trim();
      return tt === "INVIGILATION" || tt === "RESERVE";
    });

  if (!movable.length) return out;

  const MAX_SWAPS = Math.min(800, movable.length * 2);
  let swaps = 0;

  const sortedTeachers = () =>
    teacherIds
      .map((id) => ({ id, total: teacherQuotaTotals.get(id) || 0 }))
      .sort((a, b) => a.total - b.total);

  while (swaps < MAX_SWAPS) {
    const sorted = sortedTeachers();
    const low = sorted[0];
    const high = sorted[sorted.length - 1];
    if (!low || !high) break;
    if (high.total - low.total <= 1) break;

    const lowId = low.id;
    const highId = high.id;

    let moved = false;

    for (const { a } of movable) {
      const curTeacherId = String(a?.teacherId || "").trim();
      if (curTeacherId !== highId) continue;

      if (
        canTakeAssignment({
          teacherId: lowId,
          a,
          constraints,
          teacherSubjectsMapAll: subjectsMapAll,
          teacherSlotSet,
          teacherQuotaTotals,
          assignsAll: assigns,
        })
      ) {
        const sk = slotKeyOf(a);
        if (sk) removeSlot(highId, sk);

        a.teacherId = lowId;
        a.teacherName = nameMap.get(lowId) || a.teacherName || lowId;

        if (sk) addSlot(lowId, sk);

        bumpQuota(highId, -1);
        bumpQuota(lowId, +1);

        swaps += 1;
        moved = true;
        break;
      }
    }

    if (!moved) break;
  }

  if (swaps > 0) {
    out.warnings = Array.isArray(out.warnings) ? out.warnings : [];
    out.warnings.unshift(`✅ تم تحسين التوازن: إعادة توزيع ${swaps} مهمة لتحقيق عدالة أكبر.`);
  }

  return out;
}

/* ============================================================
   ✅ موازنة مراقبات INVIGILATION لتساويها قدر الإمكان
============================================================ */
function rebalanceInvigilationsToEqualize(out: any, latestTeachers: any[], constraints: any) {
  const assigns: any[] = Array.isArray(out?.assignments) ? out.assignments : [];
  if (!assigns.length) return out;

  const { subjectsMapAll, nameMap } = buildTeacherMetaMaps(latestTeachers);

  const invCount = new Map<string, number>();
  const slotSet = new Map<string, Set<string>>();

  for (const a of assigns) {
    const teacherId = String(a?.teacherId || "").trim();
    if (!teacherId) continue;

    if (!slotSet.has(teacherId)) slotSet.set(teacherId, new Set<string>());
    slotSet.get(teacherId)!.add(slotKeyOf(a));

    if (!invCount.has(teacherId)) invCount.set(teacherId, 0);
    if (String(a?.taskType || "") === "INVIGILATION") {
      invCount.set(teacherId, (invCount.get(teacherId) || 0) + 1);
    }
  }

  const teacherIds = Array.from(invCount.keys());
  if (teacherIds.length <= 1) return out;

  const movableInv = assigns.map((a) => ({ a })).filter(({ a }) => String(a?.taskType || "") === "INVIGILATION");
  if (!movableInv.length) return out;

  const smartBySpecialty = !!constraints?.smartBySpecialty;

  function currentQuotaOf(teacherId: string) {
    return assigns.filter((x) => String(x.teacherId) === teacherId && isQuotaTaskType(x.taskType)).length;
  }

  function canReceive(teacherId: string, a: any) {
    const dateISO = String(a?.dateISO || a?.date || "").trim();
    const period = String(a?.period || "").trim();
    const subj = String(a?.subject || "").trim();

    if (dateISO && isTeacherReviewFreeFullDay(assigns, teacherId, dateISO)) return false;

    const sk = `${dateISO}__${period}`;
    const slots = slotSet.get(teacherId) || new Set<string>();
    if (slots.has(sk)) return false;

    if (dateISO) {
      const allowed = isTwoPeriodsAllowedOnDate(dateISO, constraints);
      const hasAnySameDay = Array.from(slots).some((x) => x.startsWith(`${dateISO}__`));
      if (hasAnySameDay && !allowed) return false;
    }

    if (smartBySpecialty && subj) {
      const subs = subjectsMapAll.get(teacherId);
      if (subs && subs.has(subj)) return false;
    }

    const maxTasks = Number(constraints?.maxTasksPerTeacher ?? 10) || 10;
    if (currentQuotaOf(teacherId) >= maxTasks) return false;

    return true;
  }

  const sortTeachersByInv = () =>
    teacherIds.map((id) => ({ id, inv: invCount.get(id) || 0 })).sort((a, b) => a.inv - b.inv);

  const MAX_MOVES = Math.min(1200, movableInv.length * 3);
  let moves = 0;

  while (moves < MAX_MOVES) {
    const sorted = sortTeachersByInv();
    const low = sorted[0];
    const high = sorted[sorted.length - 1];
    if (!low || !high) break;
    if (high.inv - low.inv <= 0) break;

    let moved = false;

    for (const { a } of movableInv) {
      const fromId = String(a?.teacherId || "").trim();
      if (fromId !== high.id) continue;

      if (canReceive(low.id, a)) {
        const dateISO = String(a?.dateISO || a?.date || "").trim();
        const period = String(a?.period || "").trim();
        const sk = `${dateISO}__${period}`;

        slotSet.get(fromId)?.delete(sk);
        if (!slotSet.has(low.id)) slotSet.set(low.id, new Set<string>());
        slotSet.get(low.id)!.add(sk);

        a.teacherId = low.id;
        a.teacherName = nameMap.get(low.id) || a.teacherName || low.id;

        invCount.set(high.id, (invCount.get(high.id) || 0) - 1);
        invCount.set(low.id, (invCount.get(low.id) || 0) + 1);

        moves++;
        moved = true;
        break;
      }
    }

    if (!moved) break;
  }

  out.warnings = Array.isArray(out.warnings) ? out.warnings : [];

  if (moves > 0) {
    out.warnings.unshift(`✅ تم تحسين مساواة المراقبة: تم نقل ${moves} مهمة مراقبة بين المعلمين.`);
  } else {
    out.warnings.unshift("⚠️ لم يمكن مساواة المراقبة بالكامل بسبب القيود/التعارضات الحالية.");
  }

  return out;
}

export default function TaskDistributionRun() {
  const nav = useNavigate();
  const { user, profile, effectiveTenantId } = useAuth() as any;
  const { teachers: appTeachers, exams: appExams } = useAppData();

  const tenantId = String(effectiveTenantId || profile?.tenantId || user?.tenantId || "").trim() || "default";

  const [fsTeachers, setFsTeachers] = useState<any[]>([]);
  const [fsExams, setFsExams] = useState<any[]>([]);
  const [fsLoading, setFsLoading] = useState(false);

  // ✅ تحميل بيانات المعلمين/الامتحانات من Firestore داخل tenant (حتى تكون نتائج Results/Print مرتبطة بـ Run)
  useEffect(() => {
    let mounted = true;
    (async () => {
      if (!tenantId) return;
      setFsLoading(true);
      try {
        const [t, e] = await Promise.all([
          loadTenantArray<any>(tenantId, "teachers"),
          loadTenantArray<any>(tenantId, "exams"),
        ]);
        if (!mounted) return;
        setFsTeachers(Array.isArray(t) ? t : []);
        setFsExams(Array.isArray(e) ? e : []);
      } catch {
        if (!mounted) return;
        setFsTeachers([]);
        setFsExams([]);
      } finally {
        if (mounted) setFsLoading(false);
      }
    })();
    return () => {
      mounted = false;
    };
  }, [tenantId]);

  const teachers = (fsTeachers?.length ? fsTeachers : appTeachers) as any[];
  const exams = (fsExams?.length ? fsExams : appExams) as any[];

  const teachersCount = teachers?.length ?? 0;
  const examsCount = exams?.length ?? 0;
  const hasBasics = teachersCount > 0 && examsCount > 0;

  const [constraints, setConstraints] = useState<any>(() => {
    const saved = loadSavedConstraints();
    const merged = saved ? { ...DEFAULT_CONSTRAINTS, ...saved } : { ...DEFAULT_CONSTRAINTS };

    // ✅ ترحيل الإعداد القديم (يوم واحد) إلى النظام الجديد (MODE + DATES)
    const legacyOne = workDateISO(String(merged?.correctionFreeDateISO || "").trim());
    const modeRaw = String(merged?.correctionFreeMode || "").trim().toUpperCase();
    if (!modeRaw) {
      merged.correctionFreeMode = legacyOne ? "DATES" : "ALL";
    }
    if (!Array.isArray(merged?.correctionFreeDatesISO)) merged.correctionFreeDatesISO = [];
    if (legacyOne && !merged.correctionFreeDatesISO.includes(legacyOne)) merged.correctionFreeDatesISO.push(legacyOne);

    return merged;
  });

  const [errors, setErrors] = useState<string[]>([]);
  const [runtimeError, setRuntimeError] = useState<string | null>(null);
  const [isRunning, setIsRunning] = useState(false);

  const [runOut, setRunOut] = useState<any | null>(null);

  const [sortMode, setSortMode] = useState<"TOTAL_DESC" | "TOTAL_ASC" | "NAME_ASC">("TOTAL_DESC");

  const [debugOpen, setDebugOpen] = useState(true);
  const [fairnessQuery, setFairnessQuery] = useState("");

  const [lsTeachers, setLsTeachers] = useState<any[]>([]);

  const allExamDatesSorted: string[] = useMemo(() => {
    const latestExams = exams as any[];
    const s = new Set<string>();
    for (const e of latestExams) {
      const d = String(e.dateISO || e.date || "").trim();
      if (d) s.add(d);
    }
    return Array.from(s).sort();
  }, [examsCount]);

  // ✅ NEW: أيام التصحيح المحتملة = اليوم التالي لكل امتحان (بعد ترحيل الجمعة/السبت)
  const correctionDatesSorted: string[] = useMemo(() => {
    const latestExams = exams as any[];
    const s = new Set<string>();
    for (const e of latestExams) {
      const d = workDateISO(String(e.dateISO || e.date || "").trim());
      if (!d) continue;
      const cor = workDateISO(addDaysISO(d, 1));
      if (cor) s.add(cor);
    }
    return Array.from(s).sort();
  }, [examsCount]);

  useEffect(() => {
    const refresh = () => setLsTeachers(readTeachersFromLS());
    refresh();
    window.addEventListener("focus", refresh);
    return () => window.removeEventListener("focus", refresh);
  }, []);

  useEffect(() => {
    saveConstraintsToLS(constraints);
  }, [constraints]);

  useEffect(() => {
    const last = loadRun(tenantId);
    if (last) setRunOut(last);
  }, [tenantId]);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(AUTORUN_KEY);
      if (!raw) return;
      const payload = JSON.parse(raw);
      localStorage.removeItem(AUTORUN_KEY);

      const patch = payload?.patch || {};
      const nextConstraints = { ...constraints, ...patch };
      setConstraints(nextConstraints);

      setTimeout(() => {
        run(nextConstraints);
      }, 50);
    } catch {}
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tenantId]);

  function setField(key: string, value: any) {
    setConstraints((prev: any) => ({ ...prev, [key]: value }));
  }

  const derived = useMemo(() => {
    const list = exams || [];
    const uniqueDates = new Set(list.map((e: any) => String(e.dateISO || e.date || "").trim()).filter(Boolean));
    return {
      uniqueDates: uniqueDates.size,
      totalRooms: list.reduce((acc: number, e: any) => acc + (Number(e.roomsCount) || 0), 0),
    };
  }, [exams]);

  const debug: DistributionDebug | any = runOut?.debug;
  const unfilledSlots: UnfilledSlotDebug[] = (debug?.unfilled || []) as any;

  function validate(): string[] {
    const errs: string[] = [];
    // ✅ مهم: زر التشغيل يجب أن يعمل (يعرض رسالة) حتى لو لا توجد بيانات
    if (teachersCount <= 0) errs.push("❌ لا يوجد بيانات في صفحة المعلمين. الرجاء إدخال المعلمين أولاً ثم العودة للتوزيع.");
    if (examsCount <= 0) errs.push("❌ لا يوجد بيانات في صفحة جدول الامتحانات. الرجاء إدخال جدول الامتحانات أولاً ثم العودة للتوزيع.");
    if (!hasBasics) errs.push("لا يمكن التشغيل قبل إدخال بيانات المعلمين + جدول الامتحانات.");
    if ((constraints.maxTasksPerTeacher ?? 0) <= 0) errs.push("الحد الأقصى للنصاب يجب أن يكون أكبر من 0.");
    if ((constraints.reservePerPeriod ?? 0) < 0) errs.push("الاحتياط لكل فترة لا يمكن أن يكون سالب.");

    if ((constraints.invigilators_5_10 ?? 0) <= 0) errs.push("مراقبين لكل قاعة (صفوف 10) يجب أن يكون أكبر من 0.");
    if ((constraints.invigilators_11 ?? 0) <= 0) errs.push("مراقبين لكل قاعة (صفوف 11) يجب أن يكون أكبر من 0.");
    if ((constraints.invigilators_12 ?? 0) <= 0) errs.push("مراقبين لكل قاعة (أخرى/12) يجب أن يكون أكبر من 0.");

    if ((constraints.correctionDays ?? 1) <= 0) errs.push("عدد أيام التصحيح يجب أن يكون أكبر من 0.");

    if (constraints.allowTwoPeriodsSameDay) {
      const allDates = !!constraints.allowTwoPeriodsSameDayAllDates;
      const dates = Array.isArray(constraints.allowTwoPeriodsSameDayDates) ? constraints.allowTwoPeriodsSameDayDates : [];
      if (!allDates && dates.length === 0) {
        errs.push("السماح بفترتين (تواريخ محددة): اختر تاريخًا واحدًا على الأقل أو فعّل خيار (كل الأيام).");
      }
    }

    return errs;
  }

  async function run(customConstraints?: any) {
    setRuntimeError(null);

    const errs = validate();
    setErrors(errs);
    if (errs.length) return;

    setIsRunning(true);
    try {
      const latestTeachers = teachers as any[];
      const latestExams = exams as any[];

      setLsTeachers(latestTeachers);

      if (!latestTeachers.length) throw new Error("لا يوجد معلمين. تأكد من إضافة المعلمين (داخل المدرسة الحالية).");
      if (!latestExams.length) throw new Error("لا يوجد امتحانات. تأكد من إضافة جدول الامتحانات (داخل المدرسة الحالية).");

      const roomsSum = latestExams.reduce((a, e) => a + (Number(e.roomsCount) || 0), 0);
      if (roomsSum <= 0) throw new Error("مجموع عدد القاعات = 0. تأكد أن لكل امتحان roomsCount أكبر من صفر.");

      const baseConstraints = customConstraints ? { ...constraints, ...customConstraints } : constraints;

      const constraintsForEngine: any = {
        ...baseConstraints,
        allowTwoPeriodsSameDayAllDates: !!baseConstraints.allowTwoPeriodsSameDayAllDates,
        allowTwoPeriodsSameDayDates: Array.isArray(baseConstraints.allowTwoPeriodsSameDayDates)
          ? baseConstraints.allowTwoPeriodsSameDayDates
          : [],
      };

      const baseSeed = Date.now();
      const ATTEMPTS_RAW = Number(constraintsForEngine.optimizationAttempts ?? 5) || 5;
      const ATTEMPTS = Math.max(1, Math.min(20, ATTEMPTS_RAW));

      let bestOut: any | null = null;
      let bestScore = {
        invMissing: Number.POSITIVE_INFINITY,
        resMissing: Number.POSITIVE_INFINITY,
        totalMissing: Number.POSITIVE_INFINITY,
      };

      function scoreOut(o: any) {
        const unfilledList: any[] = Array.isArray(o?.debug?.unfilled) ? o.debug.unfilled : [];
        let invMissing = 0;
        let resMissing = 0;

        for (const u of unfilledList) {
          const kind = String(u?.kind || "");
          const req = Number(u?.required || 0) || 0;
          const asg = Number(u?.assigned || 0) || 0;
          const miss = Math.max(0, req - asg);
          if (kind === "INVIGILATION") invMissing += miss;
          if (kind === "RESERVE") resMissing += miss;
        }

        return { invMissing, resMissing, totalMissing: invMissing + resMissing };
      }

      for (let i = 0; i < ATTEMPTS; i++) {
        const seed = baseSeed + i * 7919;

        let candidate = runTaskDistributionLocal({
          teachers: latestTeachers,
          exams: latestExams,
          constraints: constraintsForEngine,
          runSeed: seed,
        });

        candidate = rebalanceReserveToCoverInvigilations(candidate, latestTeachers, constraintsForEngine);
        candidate = ensureExplicitTaskTypes(candidate);

        candidate = rebalanceInvigilationsToEqualize(candidate, latestTeachers, constraintsForEngine);
        candidate = rebalanceFairDistribution(candidate, latestTeachers, constraintsForEngine);

        const sc = scoreOut(candidate);

        const isBetter =
          sc.invMissing < bestScore.invMissing ||
          (sc.invMissing === bestScore.invMissing && sc.resMissing < bestScore.resMissing) ||
          (sc.invMissing === bestScore.invMissing &&
            sc.resMissing === bestScore.resMissing &&
            sc.totalMissing < bestScore.totalMissing);

        if (isBetter || !bestOut) {
          bestOut = candidate;
          bestScore = sc;
        }
      }

      const out = bestOut!;

      saveRun(tenantId, out);
      // ✅ Audit: تشغيل التوزيع
      try {
      } catch {}

      setRunOut(out);
    } catch (e: any) {
      setRuntimeError(e?.message ? String(e.message) : "حدث خطأ غير معروف أثناء التشغيل");
    } finally {
      setIsRunning(false);
    }
  }

  function deleteAllDistributionData() {
    clearRun(tenantId);

    // ✅ امسح أي جداول/ملخصات محفوظة (حتى صفحة Settings لا تعرض بيانات قديمة)
    try {
      localStorage.removeItem(MASTER_TABLE_KEY);
      localStorage.removeItem(RESULTS_TABLE_KEY);
      localStorage.removeItem(ALL_TABLE_KEY);
    } catch {}

    // ✅ أبلغ الصفحات الأخرى (Settings) بالتحديث في نفس التبويب
    try {
      window.dispatchEvent(new Event(RUN_UPDATED_EVENT));
    } catch {}
    // ✅ Audit: حذف بيانات التوزيع
    void writeTenantAudit(tenantId, {
      action: "distribution_clear",
      entity: "task_distribution",
      by: user?.uid || undefined,
      meta: { atISO: new Date().toISOString() },
    }).catch(() => {});

    setRunOut(null);
    setRuntimeError(null);
  }

  // ✅ ملخص العدالة: الإجمالي = (مراقبة + احتياط + مراجعة) فقط
  const fairnessRowsBase: FairRow[] = useMemo(() => {
    const currentTeachers = (lsTeachers || []).map((t: any) => ({
      teacherId: String(t.id),
      teacherName: String(t.fullName || t.name || "").trim(),
    }));

    const map = new Map<string, FairRow>();
    for (const t of currentTeachers) {
      map.set(t.teacherId, {
        teacherId: t.teacherId,
        teacherName: t.teacherName,
        inv: 0,
        res: 0,
        rev: 0,
        cor: 0,
        total: 0,
      });
    }

    const assigns = (runOut?.assignments || []) as any[];

    const seenReviewPerDay = new Set<string>();
    const seenCorrectionPerDay = new Set<string>();

    for (const a of assigns) {
      const teacherId = String(a.teacherId || "").trim();
      if (!teacherId) continue;

      if (!map.has(teacherId)) {
        map.set(teacherId, {
          teacherId,
          teacherName: "",
          inv: 0,
          res: 0,
          rev: 0,
          cor: 0,
          total: 0,
        });
      }

      const r = map.get(teacherId)!;

      if (!r.teacherName) {
        const tFromLS = currentTeachers.find((x) => x.teacherId === teacherId);
        r.teacherName = tFromLS?.teacherName || String(a.teacherName || teacherId);
      }

      const ttype = String(a.taskType || "").trim();

      if (ttype === "INVIGILATION") r.inv += 1;
      if (ttype === "RESERVE") r.res += 1;

      if (ttype === "REVIEW_FREE") {
        const dateISO = String(a.dateISO || a.date || "").trim();
        const key = `${teacherId}__${dateISO}`;
        if (!seenReviewPerDay.has(key)) {
          seenReviewPerDay.add(key);
          r.rev += 1;
        }
      }

      if (ttype === "CORRECTION_FREE") {
        const dateISO = String(a.dateISO || a.date || "").trim();
        const key = `${teacherId}__${dateISO}`;
        if (!seenCorrectionPerDay.has(key)) {
          seenCorrectionPerDay.add(key);
          r.cor += 1;
        }
      }

      r.total = r.inv + r.res + r.rev;
    }

    return Array.from(map.values());
  }, [lsTeachers, runOut]);

  const fairnessRows: FairRow[] = useMemo(() => {
    const q = normalizeSearch(fairnessQuery);
    let arr = [...fairnessRowsBase];

    if (q) {
      arr = arr.filter((r) => {
        const name = normalizeSearch(r.teacherName);
        const id = normalizeSearch(r.teacherId);
        return name.includes(q) || id.includes(q);
      });
    }

    if (sortMode === "TOTAL_DESC")
      arr.sort((a, b) => b.total - a.total || (a.teacherName || "").localeCompare(b.teacherName || "", "ar"));
    if (sortMode === "TOTAL_ASC")
      arr.sort((a, b) => a.total - b.total || (a.teacherName || "").localeCompare(b.teacherName || "", "ar"));
    if (sortMode === "NAME_ASC") arr.sort((a, b) => (a.teacherName || "").localeCompare(b.teacherName || "", "ar"));

    return arr;
  }, [fairnessRowsBase, fairnessQuery, sortMode]);

  // ====== UI constants (كما هي) ======
  const DARK_BLUE = "#0b1b3a";
  const DARK_BLUE_2 = "#0a1630";
  const GOLD_2 = "#c9a227"; // Dark gold
const GOLD_SUB = "rgba(201,162,39,0.75)";
  const LINE = "rgba(201,162,39,.18)";

  const page: React.CSSProperties = {
  color: GOLD_2,

    direction: "rtl",
    minHeight: "100vh",
    background: "#0a1020",
    padding: 18,
    boxSizing: "border-box",
  };

  const header: React.CSSProperties = {
    background: `linear-gradient(135deg, ${DARK_BLUE}, ${DARK_BLUE_2})`,
    borderRadius: 22,
    padding: 18,
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    gap: 14,
    boxShadow: "0 18px 50px rgba(0,0,0,.45)",
    border: `1px solid ${LINE}`,
  };

  const headerLeft: React.CSSProperties = {
    display: "flex",
    gap: 10,
    alignItems: "center",
    flexWrap: "wrap",
  };

  const hBtn: React.CSSProperties = {
    border: `1px solid ${LINE}`,
    background: "rgba(255,255,255,.06)",
    color: GOLD_2,
    borderRadius: 14,
    padding: "10px 14px",
    fontWeight: 950,
    cursor: "pointer",
    display: "inline-flex",
    gap: 8,
    alignItems: "center",
  };

  const btnMini: React.CSSProperties = {
    border: `1px solid ${LINE}`,
    background: "rgba(255,255,255,.10)",
    color: GOLD_2,
    borderRadius: 14,
    padding: "10px 14px",
    fontWeight: 950,
    cursor: "pointer",
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
  };

  const titleBox: React.CSSProperties = {
    textAlign: "right",
    display: "flex",
    alignItems: "center",
    gap: 12,
  };

  const brandText: React.CSSProperties = {
    display: "flex",
    flexDirection: "column",
    gap: 4,
  };

  const title: React.CSSProperties = {
    fontSize: 22,
    fontWeight: 950,
    margin: 0,
    lineHeight: 1.2,
    color: GOLD_2,
  };

  const subtitle: React.CSSProperties = {
    opacity: 0.9,
    fontWeight: 800,
    marginTop: 2,
    color: "rgba(201,162,39,.85)",
    fontSize: 12,
  };

  const grid3: React.CSSProperties = {
    display: "grid",
    gridTemplateColumns: "repeat(3, minmax(260px, 1fr))",
    gap: 16,
    marginTop: 16,
  };

  const card: React.CSSProperties = {
    background: `linear-gradient(180deg, ${DARK_BLUE}, ${DARK_BLUE_2})`,
    borderRadius: 20,
    padding: 16,
    boxShadow: "0 12px 35px rgba(0,0,0,.45)",
    border: `1px solid ${LINE}`,
    color: GOLD_2,
  };

  const cardHead: React.CSSProperties = {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    gap: 12,
  };

  const cardTitle: React.CSSProperties = { fontWeight: 950, color: GOLD_2, fontSize: 16 };
  const cardSub: React.CSSProperties = {
    marginTop: 4,
    color: "rgba(201,162,39,.80)",
    fontWeight: 800,
    fontSize: 12,
  };

  const row: React.CSSProperties = {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    gap: 10,
    padding: "10px 0",
    borderBottom: `1px solid ${LINE}`,
  };

  const label: React.CSSProperties = { color: GOLD_2, fontWeight: 950, fontSize: 13 };
  const note: React.CSSProperties = { color: "rgba(201,162,39,.82)", fontWeight: 800, fontSize: 12, marginTop: 2 };

  const toggle: React.CSSProperties = {
    width: 56,
    height: 30,
    borderRadius: 999,
    background: "rgba(255,255,255,.10)",
    position: "relative",
    border: `1px solid ${LINE}`,
    cursor: "pointer",
    flexShrink: 0,
  };

  const knob: React.CSSProperties = {
    width: 24,
    height: 24,
    borderRadius: 999,
    background: "#fff",
    position: "absolute",
    top: 2.5,
    left: 3,
    boxShadow: "0 6px 14px rgba(0,0,0,.35)",
    transition: "all .15s ease",
  };

  const statusChip: React.CSSProperties = {
    padding: "6px 10px",
    borderRadius: 999,
    fontWeight: 950,
    fontSize: 12,
    border: `1px solid ${LINE}`,
    background: "rgba(255,255,255,.06)",
    color: GOLD_2,
    whiteSpace: "nowrap",
  };

  const miniBtn: React.CSSProperties = {
    border: `1px solid ${LINE}`,
    background: "rgba(255,255,255,.06)",
    color: GOLD_2,
    borderRadius: 12,
    padding: "8px 12px",
    fontWeight: 950,
    cursor: "pointer",
  };

  const input: React.CSSProperties = {
    width: 130,
    padding: "10px 12px",
    borderRadius: 14,
    border: `1px solid ${LINE}`,
    outline: "none",
    fontWeight: 950,
    color: GOLD_2,
    background: "rgba(255,255,255,.06)",
    textAlign: "center",
  };

  const bigRun: React.CSSProperties = {
    marginTop: 18,
    width: "100%",
    padding: "18px 18px",
    borderRadius: 18,
    border: `1px solid ${LINE}`,
    cursor: "pointer",
    fontWeight: 950,
    fontSize: 18,
    color: GOLD_2,
    background: `linear-gradient(135deg, ${DARK_BLUE}, ${DARK_BLUE_2})`,
    boxShadow: "0 18px 45px rgba(0,0,0,.45)",
  };

  const errorsBox: React.CSSProperties = { marginTop: 12, display: "grid", gap: 8 };

  const errChip: React.CSSProperties = {
    background: "rgba(239,68,68,.12)",
    border: "1px solid rgba(239,68,68,.28)",
    color: "#fecaca",
    borderRadius: 14,
    padding: "10px 12px",
    fontWeight: 900,
  };

  const warnChip: React.CSSProperties = {
    background: "rgba(245,158,11,.12)",
    border: "1px solid rgba(245,158,11,.28)",
    color: "#fde68a",
    borderRadius: 14,
    padding: "10px 12px",
    fontWeight: 900,
  };

  const fairnessWrap: React.CSSProperties = {
    marginTop: 18,
    background: `linear-gradient(180deg, ${DARK_BLUE}, ${DARK_BLUE_2})`,
    borderRadius: 20,
    overflow: "hidden",
    boxShadow: "0 12px 35px rgba(0,0,0,.45)",
    border: `1px solid ${LINE}`,
    color: GOLD_2,
  };

  const fairnessHeader: React.CSSProperties = {
    padding: 16,
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    gap: 12,
    flexWrap: "wrap",
  };

  const fairnessTitle: React.CSSProperties = { fontWeight: 950, fontSize: 18, color: GOLD_2 };
  const fairnessSub: React.CSSProperties = {
    fontWeight: 800,
    fontSize: 12,
    color: "rgba(201,162,39,.82)",
    marginTop: 4,
  };

  const table2: React.CSSProperties = { width: "100%", borderCollapse: "separate", borderSpacing: 0 };

  const th2: React.CSSProperties = {
    position: "sticky",
    top: 0,
    textAlign: "center",
    padding: "14px 10px",
    fontWeight: 950,
    fontSize: 13,
    background: "rgba(255,255,255,.04)",
    color: GOLD_2,
    borderBottom: `1px solid ${LINE}`,
    zIndex: 2,
  };

  const td2: React.CSSProperties = {
    textAlign: "center",
    padding: "16px 10px",
    borderTop: `1px solid ${LINE}`,
    fontWeight: 900,
    color: GOLD_2,
  };

  const totalBadge: React.CSSProperties = {
    display: "inline-flex",
    width: 40,
    height: 40,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
    background: "rgba(201,162,39,.18)",
    border: `1px solid ${LINE}`,
    color: GOLD_2,
    boxShadow: "0 10px 20px rgba(0,0,0,.25)",
  };

  const pill: React.CSSProperties = {
    display: "inline-flex",
    alignItems: "center",
    gap: 8,
    padding: "8px 12px",
    borderRadius: 999,
    background: "rgba(255,255,255,.06)",
    border: `1px solid ${LINE}`,
    fontWeight: 900,
    color: GOLD_2,
  };

  const fairnessTableScroll: React.CSSProperties = {
    maxHeight: "55vh",
    overflow: "auto",
    borderTop: `1px solid ${LINE}`,
  };

  const fairnessSearchInput: React.CSSProperties = {
    width: 260,
    padding: "10px 12px",
    borderRadius: 14,
    border: `1px solid ${LINE}`,
    outline: "none",
    fontWeight: 900,
    color: GOLD_2,
    background: "rgba(255,255,255,.06)",
  };

  const grid3Responsive = grid3;

  const boolText = (v: boolean) => (v ? "مفعل" : "غير مفعل");

  const allowTwo = !!constraints.allowTwoPeriodsSameDay;
  const twoAllDates = !!constraints.allowTwoPeriodsSameDayAllDates;
  const twoDates: string[] = Array.isArray(constraints.allowTwoPeriodsSameDayDates)
    ? constraints.allowTwoPeriodsSameDayDates
    : [];

  function toggleDate(dateISO: string) {
    const d = String(dateISO || "").trim();
    if (!d) return;
    const set = new Set(twoDates);
    if (set.has(d)) set.delete(d);
    else set.add(d);
    setField("allowTwoPeriodsSameDayDates", Array.from(set).sort());
  }

  const correctionByTeacher: any[] = Array.isArray(debug?.correctionByTeacher) ? debug.correctionByTeacher : [];

  return (
    <div style={page}>
      {/* Header */}
      <div style={header}>
        <div style={headerLeft}>
          <button
            type="button"
            style={hBtn}
            onClick={() => setConstraints({ ...DEFAULT_CONSTRAINTS, ...(loadSavedConstraints() || {}) })}
            title="تحديث/إعادة تحميل القيود"
          >
            ⟲ تحديث
          </button>

          <button type="button" style={hBtn} onClick={() => saveConstraintsToLS(constraints)} title="حفظ القيود">
            💾 حفظ
          </button>

          <button
            type="button"
            style={hBtn}
            onClick={() => {
              clearConstraintsLS();
              setConstraints({ ...DEFAULT_CONSTRAINTS });
            }}
            title="حذف القيود المحفوظة"
          >
            🗑 حذف القيود
          </button>

          <button type="button" style={hBtn} onClick={() => nav("/")} title="لوحة التحكم">
            ☐ لوحة التحكم
          </button>

          <button type="button" style={hBtn} onClick={() => nav("/task-distribution/results")} title="الجدول الشامل">
            ▦ الجدول الشامل
          </button>

          <button type="button" style={hBtn} onClick={() => nav("/task-distribution/suggestions")} title="الاقتراحات">
            💡 الاقتراحات
          </button>

          <button type="button" style={hBtn} onClick={deleteAllDistributionData} title="حذف جميع بيانات التوزيع">
            ✖ حذف بيانات التوزيع
          </button>
        </div>
      </div>

      {/* 3 Cards */}
      <div style={grid3Responsive}>
        {/* القيود والانصبة */}
        <div style={card}>
          <div style={cardHead}>
            <div>
              <div style={cardTitle}>القيود والانصبة</div>
              <div style={cardSub}>الحد الأقصى للنصاب (مراقبة + احتياط + مراجعة)</div>
            </div>
            <div style={{ fontSize: 18, opacity: 0.9, color: GOLD_2 }}>🎚️</div>
          </div>

          <div style={{ marginTop: 10 }}>
            <div style={row}>
              <div>
                <div style={label}>الحد الأقصى للنصاب</div>
                <div style={note}>لكل معلم = مراقبة + احتياط + مراجعة فقط</div>
              </div>
              <input
                style={input}
                inputMode="numeric"
                value={String(constraints.maxTasksPerTeacher)}
                onChange={(e) => setField("maxTasksPerTeacher", num(e.target.value, 10))}
              />
            </div>

            <div style={row}>
              <div>
                <div style={label}>الاحتياط لكل فترة</div>
                <div style={note}>يتوزع بعد المراقبة — ويُلغى يوم العجز</div>
              </div>
              <input
                style={input}
                inputMode="numeric"
                value={String(constraints.reservePerPeriod ?? 1)}
                onChange={(e) => setField("reservePerPeriod", num(e.target.value, 1))}
              />
            </div>

            <div style={row}>
              <div>
                <div style={label}>عدد أيام التصحيح</div>
                <div style={note}>المنطق هنا يوم واحد بعد الامتحان (ثابت)</div>
              </div>
              <input
                style={input}
                inputMode="numeric"
                value={String(constraints.correctionDays ?? 1)}
                onChange={(e) => setField("correctionDays", num(e.target.value, 1))}
              />
            </div>

            <div style={{ ...row, borderBottom: "none" }}>
              <div>
                <div style={label}>عدد محاولات التحسين</div>
                <div style={note}>يعيد التشغيل بعدة محاولات ويختار الأقل عجزًا (3/5/10)</div>
              </div>
              <select
                style={{ ...input, width: 140, cursor: "pointer" }}
                value={String(constraints.optimizationAttempts ?? 5)}
                onChange={(e) => setField("optimizationAttempts", num(e.target.value, 5))}
              >
                {[1, 3, 5, 10, 15].map((n) => (
                  <option key={n} value={String(n)}>
                    {n}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* إعدادات القاعات */}
        <div style={card}>
          <div style={cardHead}>
            <div>
              <div style={cardTitle}>إعدادات القاعات</div>
              <div style={cardSub}>تحديد عدد المراقبين لكل قاعة</div>
            </div>
            <div style={{ fontSize: 18, opacity: 0.9, color: GOLD_2 }}>👥</div>
          </div>

          <div style={{ marginTop: 10 }}>
            <div style={row}>
              <div>
                <div style={label}>صفوف 10</div>
                <div style={note}>عدد المراقبين لكل قاعة</div>
              </div>
              <input
                style={input}
                inputMode="numeric"
                value={String(constraints.invigilators_5_10)}
                onChange={(e) => setField("invigilators_5_10", num(e.target.value, 2))}
              />
            </div>

            <div style={row}>
              <div>
                <div style={label}>صفوف 11</div>
                <div style={note}>عدد المراقبين لكل قاعة</div>
              </div>
              <input
                style={input}
                inputMode="numeric"
                value={String(constraints.invigilators_11)}
                onChange={(e) => setField("invigilators_11", num(e.target.value, 2))}
              />
            </div>

            <div style={{ ...row, borderBottom: "none" }}>
              <div>
                <div style={label}>أخرى (12)</div>
                <div style={note}>عدد المراقبين لكل قاعة</div>
              </div>
              <input
                style={input}
                inputMode="numeric"
                value={String(constraints.invigilators_12)}
                onChange={(e) => setField("invigilators_12", num(e.target.value, 2))}
              />
            </div>
          </div>
        </div>

        {/* بطاقة الخيارات المتقدمة */}
        <div style={card}>
          <div style={cardHead}>
            <div>
              <div style={cardTitle}>خيارات متقدمة</div>
              <div style={cardSub}>قيود ذكية + مفعل/غير مفعل</div>
            </div>
            <div style={{ fontSize: 18, opacity: 0.9, color: GOLD_2 }}>✨</div>
          </div>

          <div style={{ marginTop: 10 }}>
            {/* Back-to-Back */}
            <div style={row}>
              <div>
                <div style={label}>تجنب المهام المتتالية (Back-to-Back)</div>
                <div style={note}>منع تكليف نفس المعلم بفترتين في نفس اليوم (حسب السماح)</div>
              </div>

              <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                <span style={statusChip}>{boolText(!!constraints.avoidBackToBack)}</span>
                <div
                  style={{
                    ...toggle,
                    background: constraints.avoidBackToBack ? "rgba(201,162,39,.20)" : "rgba(255,255,255,.10)",
                  }}
                  onClick={() => setField("avoidBackToBack", !constraints.avoidBackToBack)}
                >
                  <div style={{ ...knob, left: constraints.avoidBackToBack ? 28 : 3 }} />
                </div>
              </div>
            </div>

            {/* Specialty block */}
            <div style={row}>
              <div>
                <div style={label}>منع مراقبة نفس المادة</div>
                <div style={note}>لا يُوزّع معلم المادة كمراقب لامتحان مادته</div>
              </div>

              <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                <span style={statusChip}>{boolText(!!constraints.smartBySpecialty)}</span>
                <div
                  style={{
                    ...toggle,
                    background: constraints.smartBySpecialty ? "rgba(201,162,39,.20)" : "rgba(255,255,255,.10)",
                  }}
                  onClick={() => setField("smartBySpecialty", !constraints.smartBySpecialty)}
                >
                  <div style={{ ...knob, left: constraints.smartBySpecialty ? 28 : 3 }} />
                </div>
              </div>
            </div>

            {/* Free correction */}
            <div style={row}>
              <div>
                <div style={label}>تفريغ جميع معلمي المادة للتصحيح</div>
                <div style={note}>اليوم التالي فقط + صفوف 1-4 (مطابقة نصية) + صفوف 5-12 (مجموعات) — ويمكن تحديد يوم تصحيح بعينه</div>
              </div>

              <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                <span style={statusChip}>{boolText(!!constraints.freeAllSubjectTeachersForCorrection)}</span>
                <div
                  style={{
                    ...toggle,
                    background: constraints.freeAllSubjectTeachersForCorrection ? "rgba(201,162,39,.20)" : "rgba(255,255,255,.10)",
                  }}
                  onClick={() => setField("freeAllSubjectTeachersForCorrection", !constraints.freeAllSubjectTeachersForCorrection)}
                >
                  <div style={{ ...knob, left: constraints.freeAllSubjectTeachersForCorrection ? 28 : 3 }} />
                </div>
              </div>
            </div>

            {/* ✅ NEW: اختيار أيام تفريغ التصحيح (مثل النموذج) */}
            {constraints.freeAllSubjectTeachersForCorrection ? (
              <div style={{ ...row, borderBottom: "none", paddingTop: 12, paddingBottom: 12, display: "block" }}>
                <div>
                  <div style={label}>تفريغ التصحيح حسب تواريخ</div>
                  <div style={note}>
                    اختر وضع التفريغ: <b>كل الأيام</b> (اليوم التالي لكل امتحان) أو <b>تواريخ محددة</b>.
                    في وضع التواريخ المحددة: اليوم الذي تحدده يتم التفريغ به فقط، وغير المحدد لا يتم التفريغ به.
                  </div>
                </div>

                {(() => {
                  const mode = String(constraints.correctionFreeMode || "ALL").toUpperCase() === "DATES" ? "DATES" : "ALL";
                  const selected: string[] = Array.isArray(constraints.correctionFreeDatesISO) ? constraints.correctionFreeDatesISO : [];
                  const selectedSet = new Set(selected.map((d) => workDateISO(String(d || "").trim())).filter(Boolean));

                  const toggleDate = (d: string) => {
                    const iso = workDateISO(d);
                    if (!iso) return;
                    const next = new Set(selectedSet);
                    if (next.has(iso)) next.delete(iso);
                    else next.add(iso);
                    setConstraints((p: any) => ({
                      ...p,
                      correctionFreeMode: "DATES",
                      correctionFreeDatesISO: Array.from(next).sort(),
                      correctionFreeDateISO: "", // لا نستخدم القديم
                    }));
                  };

                  const selectAll = () => {
                    setConstraints((p: any) => ({
                      ...p,
                      correctionFreeMode: "DATES",
                      correctionFreeDatesISO: [...correctionDatesSorted],
                      correctionFreeDateISO: "",
                    }));
                  };

                  const clearAll = () => {
                    setConstraints((p: any) => ({
                      ...p,
                      correctionFreeMode: "DATES",
                      correctionFreeDatesISO: [],
                      correctionFreeDateISO: "",
                    }));
                  };

                  const setAllMode = () => {
                    setConstraints((p: any) => ({
                      ...p,
                      correctionFreeMode: "ALL",
                      correctionFreeDateISO: "",
                    }));
                  };

                  const sum = runOut?.debug?.summary || {};
                  const shortageByDate: Record<string, number> = (sum.correctionFreeInvShortageByDate as any) || {};
                  const suggestedByDate: Record<string, string> = (sum.correctionFreeSuggestedDatesByDate as any) || {};
                  const shortageDates = Object.keys(shortageByDate || {}).filter((d) => (Number(shortageByDate[d]) || 0) > 0);

                  return (
                    <div style={{ marginTop: 10 }}>
                      <div style={{ display: "flex", gap: 10, flexWrap: "wrap", justifyContent: "flex-start" }}>
                        <button
                          style={{ ...btnMini, background: mode === "ALL" ? "rgba(201,162,39,.25)" : "rgba(255,255,255,.10)" }}
                          onClick={setAllMode}
                          title="تفريغ في كل أيام التصحيح"
                        >
                          ✅ كل الأيام
                        </button>

                        <button
                          style={{ ...btnMini, background: mode === "DATES" ? "rgba(201,162,39,.25)" : "rgba(255,255,255,.10)" }}
                          onClick={() => setConstraints((p: any) => ({ ...p, correctionFreeMode: "DATES" }))}
                          title="تفريغ حسب تواريخ محددة"
                        >
                          📅 تواريخ محددة
                        </button>

                        <button style={btnMini} onClick={selectAll} title="تحديد كل الأيام المتاحة">
                          تحديد الكل
                        </button>
                        <button style={btnMini} onClick={clearAll} title="مسح الاختيارات">
                          مسح
                        </button>
                      </div>

                      {mode === "DATES" ? (
                        <div style={{ marginTop: 10, padding: 12, border: `1px solid ${LINE}`, borderRadius: 18, background: "rgba(0,0,0,.18)" }}>
                          <div style={{ fontWeight: 900, marginBottom: 10, color: "rgba(255,255,255,.90)" }}>اختر التواريخ التي يسمح فيها بالتفريغ:</div>

                          <div
                            style={{
                              display: "grid",
                              gridTemplateColumns: "repeat(2, minmax(0, 1fr))",
                              gap: 10,
                            }}
                          >
                            {correctionDatesSorted.map((d) => {
                              const isOn = selectedSet.has(d);
                              return (
                                <label
                                  key={d}
                                  style={{
                                    display: "flex",
                                    alignItems: "center",
                                    justifyContent: "space-between",
                                    gap: 10,
                                    padding: "14px 16px",
                                    borderRadius: 18,
                                    border: `1px solid ${LINE}`,
                                    background: "rgba(255,255,255,.06)",
                                    cursor: "pointer",
                                  }}
                                >
                                  <span style={{ fontSize: 18, fontWeight: 900, color: GOLD_2 }}>{d}</span>
                                  <input
                                    type="checkbox"
                                    checked={isOn}
                                    onChange={() => toggleDate(d)}
                                    style={{ width: 22, height: 22 }}
                                  />
                                </label>
                              );
                            })}
                          </div>

                          {/* اقتراحات عند العجز */}
                          {shortageDates.length ? (
                            <div style={{ marginTop: 10, fontSize: 12.5, fontWeight: 900, color: "rgba(255,255,255,.85)" }}>
                              {shortageDates.map((d) => (
                                <div key={d} style={{ marginTop: 6 }}>
                                  ⚠️ عجز مراقبة في {d} = {Number(shortageByDate[d]) || 0} — اقتراح يوم بديل: <span style={{ color: GOLD_2 }}>{suggestedByDate[d] || "—"}</span>
                                </div>
                              ))}
                            </div>
                          ) : null}
                        </div>
                      ) : null}
                    </div>
                  );
                })()}
              </div>
            ) : null}

            {/* Allow two periods same day */}
            <div style={{ ...row, borderBottom: allowTwo ? `1px solid ${LINE}` : "none" }}>
              <div>
                <div style={label}>السماح بفترتين في اليوم الواحد</div>
                <div style={note}>اختر: كل الأيام أو تواريخ محددة فقط</div>
              </div>

              <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                <span style={statusChip}>{boolText(allowTwo)}</span>
                <div
                  style={{
                    ...toggle,
                    background: allowTwo ? "rgba(201,162,39,.20)" : "rgba(255,255,255,.10)",
                  }}
                  onClick={() => {
                    const next = !allowTwo;
                    setField("allowTwoPeriodsSameDay", next);
                    if (next && typeof constraints.allowTwoPeriodsSameDayAllDates !== "boolean") {
                      setField("allowTwoPeriodsSameDayAllDates", true);
                    }
                    if (next && !Array.isArray(constraints.allowTwoPeriodsSameDayDates)) {
                      setField("allowTwoPeriodsSameDayDates", []);
                    }
                  }}
                >
                  <div style={{ ...knob, left: allowTwo ? 28 : 3 }} />
                </div>
              </div>
            </div>

            {allowTwo ? (
              <div
                style={{
                  marginTop: 10,
                  padding: 12,
                  borderRadius: 16,
                  border: `1px solid ${LINE}`,
                  background: "rgba(255,255,255,.03)",
                }}
              >
                <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 10 }}>
                  <div>
                    <div style={label}>نطاق السماح بفترتين</div>
                    <div style={note}>كل الأيام أو تواريخ محددة فقط</div>
                  </div>
                  <span style={{ ...pill, whiteSpace: "nowrap" }}>{twoAllDates ? "كل الأيام" : `تواريخ محددة (${twoDates.length})`}</span>
                </div>

                <div style={{ display: "flex", gap: 10, flexWrap: "wrap", marginTop: 10 }}>
                  <button
                    type="button"
                    style={{
                      ...miniBtn,
                      background: twoAllDates ? "rgba(201,162,39,.20)" : "rgba(255,255,255,.06)",
                    }}
                    onClick={() => setField("allowTwoPeriodsSameDayAllDates", true)}
                  >
                    ✅ كل الأيام
                  </button>

                  <button
                    type="button"
                    style={{
                      ...miniBtn,
                      background: !twoAllDates ? "rgba(201,162,39,.20)" : "rgba(255,255,255,.06)",
                    }}
                    onClick={() => setField("allowTwoPeriodsSameDayAllDates", false)}
                  >
                    📅 تواريخ محددة
                  </button>

                  {!twoAllDates ? (
                    <>
                      <button type="button" style={miniBtn} onClick={() => setField("allowTwoPeriodsSameDayDates", [...allExamDatesSorted])}>
                        تحديد الكل
                      </button>
                      <button type="button" style={miniBtn} onClick={() => setField("allowTwoPeriodsSameDayDates", [])}>
                        مسح
                      </button>
                    </>
                  ) : null}
                </div>

                {!twoAllDates ? (
                  <div style={{ marginTop: 12 }}>
                    {allExamDatesSorted.length === 0 ? (
                      <div style={note}>لا توجد تواريخ امتحانات لعرضها. تأكد من جدول الامتحانات.</div>
                    ) : (
                      <div style={{ display: "grid", gap: 8 }}>
                        <div style={{ ...note, marginTop: 2 }}>اختر التواريخ التي يُسمح فيها بفترتين.</div>

                        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
                          {allExamDatesSorted.map((d) => {
                            const checked = twoDates.includes(d);
                            return (
                              <label
                                key={d}
                                style={{
                                  display: "flex",
                                  alignItems: "center",
                                  justifyContent: "space-between",
                                  gap: 10,
                                  padding: "10px 12px",
                                  borderRadius: 14,
                                  border: `1px solid ${LINE}`,
                                  background: checked ? "rgba(201,162,39,.14)" : "rgba(255,255,255,.04)",
                                  cursor: "pointer",
                                  fontWeight: 900,
                                }}
                              >
                                <span>{d}</span>
                                <input type="checkbox" checked={checked} onChange={() => toggleDate(d)} style={{ width: 18, height: 18 }} />
                              </label>
                            );
                          })}
                        </div>
                      </div>
                    )}
                  </div>
                ) : null}
              </div>
            ) : null}
          </div>
        </div>
      </div>

      {/* زر التشغيل */}
      <button
        type="button"
        style={{ ...bigRun, opacity: !hasBasics || isRunning ? 0.7 : 1 }}
        onClick={run}
        // ✅ لا نعطل الزر عند عدم وجود بيانات — نعرض رسالة ونمنع التشغيل داخل validate()
        disabled={isRunning}
        title={!hasBasics ? "أدخل المعلمين وجدول الامتحانات أولاً" : ""}
      >
        {isRunning ? "جارٍ تشغيل الخوارزمية..." : "تشغيل خوارزمية التوزيع"}
      </button>

      {/* أخطاء التحقق */}
      {errors.length > 0 && (
        <div style={errorsBox}>
          {errors.map((e, i) => (
            <div key={i} style={errChip}>
              {e}
            </div>
          ))}
        </div>
      )}

      {/* خطأ تشغيل */}
      {runtimeError && (
        <div style={errorsBox}>
          <div style={errChip}>❌ خطأ أثناء التشغيل: {runtimeError}</div>
        </div>
      )}

      {/* تحذيرات */}
      {runOut?.warnings?.length ? (
        <div style={errorsBox}>
          {runOut.warnings.map((w: string, i: number) => (
            <div key={i} style={warnChip}>
              {w}
            </div>
          ))}
        </div>
      ) : null}

      {/* Debug */}
      {debug ? (
        <div style={{ ...card, marginTop: 18 }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 12 }}>
            <div>
              <div style={{ fontWeight: 950, fontSize: 16, color: GOLD_2 }}>لوحة التشخيص (Debug)</div>
              <div style={{ ...cardSub, marginTop: 4 }}>
                تُظهر المطلوب/الموزع + تواريخ التصحيح الفعلية + أيام أُلغي فيها الاحتياط بسبب عجز مراقبة.
              </div>
            </div>

            <button type="button" style={hBtn} onClick={() => setDebugOpen((s) => !s)}>
              {debugOpen ? "إخفاء" : "إظهار"}
            </button>
          </div>

          {debugOpen ? (
            <>
              <div style={{ display: "flex", gap: 10, flexWrap: "wrap", marginTop: 12 }}>
                <span style={pill}>
                  مراقبة: {debug.summary.invAssigned}/{debug.summary.invRequired}
                </span>
                <span style={pill}>
                  احتياط: {debug.summary.reserveAssigned}/{debug.summary.reserveRequired}
                </span>
                <span style={pill}>مراجعة (أيام×معلمين): {debug.summary.reviewFreeTeachersDays}</span>
                <span style={pill}>تصحيح (أيام×معلمين): {debug.summary.correctionFreeTeachersDays}</span>
                <span style={pill}>معلمين: {debug.summary.teachersTotal}</span>
                <span style={pill}>امتحانات: {debug.summary.examsTotal}</span>
              </div>

              {Array.isArray(debug?.summary?.daysNoReserveBecauseInvShortage) && debug.summary.daysNoReserveBecauseInvShortage.length ? (
                <div style={{ marginTop: 10, ...note }}>
                  ⚠️ تم إلغاء توزيع الاحتياط في الأيام التالية بسبب عجز مراقبة: {debug.summary.daysNoReserveBecauseInvShortage.join(" , ")}
                </div>
              ) : null}

              <div style={{ marginTop: 14, borderTop: `1px solid ${LINE}`, paddingTop: 14 }}>
                <div style={{ fontWeight: 950, marginBottom: 10 }}>📌 التصحيح الفعلي لكل معلم (Teacher → Correction Dates)</div>

                {correctionByTeacher.length === 0 ? (
                  <div style={note}>لا توجد أيام تصحيح محسوبة.</div>
                ) : (
                  <div style={{ overflow: "auto" }}>
                    <table style={{ width: "100%", borderCollapse: "separate", borderSpacing: 0 }}>
                      <thead>
                        <tr>
                          <th style={th2}>المعلم</th>
                          <th style={th2}>TeacherId</th>
                          <th style={th2}>عدد الأيام</th>
                          <th style={{ ...th2, textAlign: "right", paddingRight: 16 }}>تواريخ التصحيح</th>
                        </tr>
                      </thead>
                      <tbody>
                        {correctionByTeacher.map((r, idx) => (
                          <tr key={`${r.teacherId}-${idx}`}>
                            <td style={{ ...td2, textAlign: "right", paddingRight: 16 }}>{r.teacherName}</td>
                            <td style={td2}>{r.teacherId}</td>
                            <td style={td2}>{r.correctionDaysCount}</td>
                            <td style={{ ...td2, textAlign: "right", paddingRight: 16, fontWeight: 800, opacity: 0.95 }}>
                              {(r.correctionDates || []).join(" , ")}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>

              {unfilledSlots.length ? (
                <div style={{ marginTop: 14, borderTop: `1px solid ${LINE}`, paddingTop: 14 }}>
                  <div style={{ fontWeight: 950, marginBottom: 10 }}>سلوطات ناقصة (لم تُغطَّ بالكامل)</div>

                  <div style={{ overflow: "auto" }}>
                    <table style={{ width: "100%", borderCollapse: "separate", borderSpacing: 0 }}>
                      <thead>
                        <tr>
                          <th style={th2}>النوع</th>
                          <th style={th2}>التاريخ</th>
                          <th style={th2}>الفترة</th>
                          <th style={{ ...th2, textAlign: "right", paddingRight: 16 }}>المادة</th>
                          <th style={th2}>المطلوب</th>
                          <th style={th2}>الموزّع</th>
                          <th style={{ ...th2, textAlign: "right", paddingRight: 16 }}>أكثر الأسباب</th>
                        </tr>
                      </thead>
                      <tbody>
                        {unfilledSlots.map((u, idx) => {
                          const topReasons = (u.reasons || []).slice(0, 3);
                          return (
                            <tr key={`${u.kind}-${u.dateISO}-${u.period}-${idx}`}>
                              <td style={td2}>{u.kind === "INVIGILATION" ? "مراقبة" : "احتياط"}</td>
                              <td style={td2}>{u.dateISO}</td>
                              <td style={td2}>{u.period === "AM" ? "الفترة الأولى" : "الفترة الثانية"}</td>
                              <td style={{ ...td2, textAlign: "right", paddingRight: 16 }}>{u.subject || "-"}</td>
                              <td style={td2}>{u.required}</td>
                              <td style={td2}>{u.assigned}</td>
                              <td style={{ ...td2, textAlign: "right", paddingRight: 16, fontWeight: 800, opacity: 0.9 }}>
                                {topReasons.length ? topReasons.map((r) => `${reasonLabel(r.code)} (${r.count})`).join(" • ") : "-"}
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>
              ) : (
                <div style={{ marginTop: 12, ...note }}>✅ لا يوجد سلوطات ناقصة — التوزيع مكتمل حسب القيود الحالية.</div>
              )}
            </>
          ) : null}
        </div>
      ) : null}

      {/* جدول العدالة */}
      <div style={fairnessWrap}>
        <div style={fairnessHeader}>
          <div>
            <div style={fairnessTitle}>ملخص عدالة التوزيع</div>
            <div style={fairnessSub}>الإجمالي = مراقبة + احتياط + مراجعة فقط (التصحيح خارج النصاب)</div>
          </div>

          <div style={{ display: "flex", gap: 10, alignItems: "center", flexWrap: "wrap" }}>
            <button type="button" style={hBtn} onClick={() => nav("/task-distribution/results")} title="الجدول الشامل">
              📋 الجدول الشامل
            </button>

            <button type="button" style={hBtn} onClick={deleteAllDistributionData} title="حذف جميع بيانات التوزيع">
              ✖ حذف بيانات التوزيع
            </button>

            <input
              style={fairnessSearchInput}
              placeholder="بحث في المعلمين (اسم/ID)..."
              value={fairnessQuery}
              onChange={(e) => setFairnessQuery(e.target.value)}
            />

            <button type="button" style={hBtn} onClick={() => setFairnessQuery("")} title="مسح البحث">
              ✕ مسح
            </button>

            <span style={{ fontWeight: 900, color: "rgba(201,162,39,.82)" }}>الترتيب:</span>
            <select
              style={{
                padding: "10px 12px",
                borderRadius: 14,
                border: `1px solid ${LINE}`,
                background: "rgba(255,255,255,.06)",
                fontWeight: 950,
                outline: "none",
                color: GOLD_2,
              }}
              value={sortMode}
              onChange={(e) => setSortMode(e.target.value as any)}
            >
              <option value="TOTAL_DESC">من الأعلى عبئًا إلى الأقل</option>
              <option value="TOTAL_ASC">من الأقل عبئًا إلى الأعلى</option>
              <option value="NAME_ASC">حسب الاسم (أ-ي)</option>
            </select>

            <span style={pill}>المعروض: {fairnessRows.length}</span>
            <span style={pill}>الإجمالي: {lsTeachers.length}</span>
          </div>
        </div>

        <div style={fairnessTableScroll}>
          <table style={table2}>
            <thead>
              <tr>
                <th style={{ ...th2, width: 60 }}>#</th>
                <th style={{ ...th2, textAlign: "right", paddingRight: 16 }}>اسم المعلم</th>
                <th style={th2}>مراقبة</th>
                <th style={th2}>احتياط</th>
                <th style={th2}>مراجعة</th>
                <th style={th2}>تصحيح</th>
                <th style={th2}>الإجمالي *</th>
              </tr>
            </thead>

            <tbody>
              {fairnessRows.length === 0 ? (
                <tr>
                  <td style={td2} colSpan={7}>
                    لا توجد نتائج مطابقة للبحث.
                  </td>
                </tr>
              ) : (
                fairnessRows.map((r, idx) => (
                  <tr key={r.teacherId}>
                    <td style={td2}>{idx + 1}</td>
                    <td style={{ ...td2, textAlign: "right", paddingRight: 16 }}>{r.teacherName || r.teacherId}</td>
                    <td style={td2}>{r.inv}</td>
                    <td style={td2}>{r.res}</td>
                    <td style={td2}>{r.rev}</td>
                    <td style={td2}>{r.cor}</td>
                    <td style={td2}>
                      <span style={totalBadge}>{r.total}</span>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* ملخص سريع */}
      <div style={{ ...card, marginTop: 18 }}>
        <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
          <span style={pill}>المعلمين: {teachersCount}</span>
          <span style={pill}>الامتحانات: {examsCount}</span>
          <span style={pill}>الأيام: {derived.uniqueDates}</span>
          <span style={pill}>إجمالي القاعات: {derived.totalRooms}</span>
        </div>
      </div>
    </div>
  );
}
